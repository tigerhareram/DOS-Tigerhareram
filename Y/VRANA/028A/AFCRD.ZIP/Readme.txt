Thank you for evaluating Business Card Creator for Word for Windows.
Copyright 1996, By Andrew M. Freeman, AMF.

>>PLEASE SEE REGISTER.TXT for ordering information and order form. Thanks!<<

Q: How do I install it?

A: Simply unzip all the files that came with the file you downloaded or received into one
   directory.

Then, run SETUP.EXE. That's it.


>>PLEASE SEE REGISTER.TXT for ordering information and order form. Thanks!<<

Please send comments/suggestions/comments/problems/bug information to:

Andrew M. Freeman
AMF
P.O. Box 189
Holbrook, N.Y. 11741-0189
USA

or by e-mail:
74250,1700 (CompuServe)
74250.1700@compuserve.com (Internet)

World Wide Web: http://execpc.com/~amfsoft/index.html


Please Register Today!

>>PLEASE SEE REGISTER.TXT for ordering information and order form. Thanks!<<

DISCLAIMER:
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" AND WITHOUT WARRANTIES AS TO 
PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED. Because 
of the various hardware and software environments into which this program and templates (All 
Versions) may be put, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS OFFERED. Good data 
processing procedure dictates that any program be thoroughly tested with non-critical data 
before relying on it. The user must assume the entire risk of using the program. 

____________________

Did you notice the installer for this program?
It�s called WISE Installation System and we at AMF love this product.
Interested?
Give the people at Great Lake Business Solutions a call for more
information and a free sample!
Visit their web site at http://www.glbs.com or call 1-800-554-8565.
