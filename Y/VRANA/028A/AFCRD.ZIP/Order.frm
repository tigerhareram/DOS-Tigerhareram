
Order Form: Business Card Creator

Last Name:_____________________________________________________

First Name:_____________________________________________________

E-Mail Address:________________________________________

Address (State, (Province), Postal Code):

________________________________________________________________

________________________________________________________________

________________________________________________________________

Quantity _____ @ $10.00 (US) each = Total $___________
PLEASE: Make Checks Payable to A M Freeman.

For a site license or bulk discount rate or for a special arrangement,
please contact Andrew M. Freeman at: 

Andrew M. Freeman
AMF
P.O. Box 189
Holbrook, N.Y. 11741-0189
USA


Add $5 for 3.5" Disks with the current version.
Disks _____ @ $5 (US): Total $_________


Internet: 74250.1700@compuserve.com
CIS: 74250,1700

Ground Mail: P.O. Box 189
             Holbrook, N.Y. 11741-0189
             USA


Comments/Suggestions/Notes/Additional Information______________________

_______________________________________________________________________


PLEASE: Make Checks Payable to A M Freeman.