RogSoft NotePad+
Version 1.11
Copyright (C) 1996 Rogier Meurs

This document is best viewed with NotePad+.

-----------------------------------------------------------------------
New users should read the installation part before installing NotePad+.
-----------------------------------------------------------------------

NotePad+ is a free drop-in replacement for Windows 95/NT 4.0 notepad, that eats standard notepad for lunch!

Features: no more file size barrier under Windows 95, opens multiple files, MAPI enabled to send files through e-mail, drag-and-drop of selected text, user-definable fonts & colors, Open- & Save dialogs Filters, smarter hot keys, numerous other improvements over standard notepad.


Contents of this file:
----------------------
1. Installation
2. Uninstall
3. The Story
4. Tips/More Information
5. Credits
6. History
7. License & Disclaimer


1. Installation:
----------------
Upgraders from an earlier version: delete the NotePad+ key in the registry before installing. It's located at HKEY_CURRENT_USER\Software\RogSoft\NotePad+, use RegEdit or any other Registry Editor to delete this key.

COPY the standard Notepad program file (notepad.exe) from your Windows directory into a temporary directory. Then place the executable file from the distribution archive of NotePad+ (also named notepad.exe) in your Windows directory, confirm the overwriting of standard Notepad. After that rename the old notepad.exe in the temporary directory (for example, rename it to Notepad Original) and move it back to your Windows directory (that's necessary for the uninstall).

Make sure that you COPY, not move, the old Notepad out of the Windows directory first before dropping NotePad+ in, and also not rename it before dropping NotePad+ in. Otherwise Windows will automatically change the path or name of the associated executable to the temporary directory or new name. Looks like there's is some object-orientedness in the Windows 95 GUI after all. :)

Users who have an anti-virus program running in the background ought to
re-inoculate the notepad.exe file before they launch the program for the first time.

After installing, associate your preferred file types with NotePad+ (in Options/Preferences/Associations), to get the full benefits of the program. Associate at least '.txt', '.bat', '.ini' and '.reg' files by simply clicking the Defaults button, for proper operation.


2. Uninstall:
-------------
In case you want to return to your old Notepad, do the following:

In Options/Preferences/Associations, delete all associations with NotePad+ and click OK. This will restore the exact original Windows associations for .txt, .bat, .ini and .reg files and will delete the other File type associations you had made with NotePad+.

In your Windows directory, delete the NotePad+ executable (notepad.exe). Rename the original Notepad (which you had backed up under a name like Notepad Original) back to notepad (or notepad.exe when you have configured Explorer to show extensions). 

You also might want to remove Notepad+'s user-preferences keys in the Registry, but it's not necessity. They are located at HKEY_CURRENT_USER\Software\RogSoft\NotePad+.


3. The Story:
-------------
I hated the limitations of standard Windows 95 Notepad so much, that I decided to write a better one. :)

My goal was to go beyond standard Notepad's possibilities without making NotePad+ a full-featured text-editor, in order to retain a fast executable and smooth operation in memory-constraint environments.

The program was developed using Delphi 2.0 and is a 100% 32-bit compiled Win32 executable, no run-time libraries are necessary to run it. I hope you'll enjoy this program, and would like as much feedback as possible.

Comments, suggestions, bug reports, fan mail, etc. are welcome at: 0meurs01@lelystad.flnet.nl

Updates will be placed at the RogSoft NotePad+ Home Page: http://lelystad.flnet.nl/~0meurs01


4. Tips/More Information:
-------------------------
You've probably noticed the behaviour of Windows 95 applications, to automatically add an extension to a file that is saved. Naturally, this has a reason. The extensions are associated with programs and you are able to open a file by just double-clicking it. But sometimes it can be annoying, especially with files for which you prefer it would not automatically get any extension. You can overrule this behaviour by typing the filename in the Save dialog box like this: "test" (WITH quotes). In this case the file will be saved without any extension. This works for NotePad+, but also for other Win95 applications that make use of the standard Win95 Save dialog.

Another thing is that Windows 95 applications (including NotePad+) can save a file with the particular extension you want it to have, just by typing in the file and extension in the Save dialog box. For example: "file_id.diz" (WITH quotes) will save your file with the extension '.diz', not '.txt', regardless of the Save As Filter that is selected. Therefore, even though '.txt' is the default extension in NotePad+, specifying your own extension in the Save-dialog box -and placing the filename in quotes- will save your file with the extension you want it to have.
The quotes are not necessary if you save a file with a particular extension that is registered in Explorer. But as a rule of thumb, remember that placing a file with a specific extension in quotes always works. Win95 makes _some_ simple things more complicated than it was in the DOS-age, I hope this information will clear things up.

To make use of the e-mail functionality of NotePad+, you have to have a MAPI-server installed. If you would like Euroda to act as your MAPI-server, do the following: go to Tools/Options/MAPI in Eudora, set 'Use Eudora MAPI server' to Always. That's all there is to it.

About running NotePad+ under Windows NT 3.51: it seems that the program doesn't fully operate on NT 3.51 as it does on Win95 and NT 4.0. For example, dragging on the minimized program icon does not work. Since I develop NotePad+ on Windows 95, it's very hard to cure those problems. If I would upgrade to NT (which might happen in a couple of months), it would be version 4.0. Therefore, there will be no efforts to make NotePad+ fully NT 3.51 compatible. It may sound hard, but NotePad+ just wasn't designed for, nor tested on, NT 3.51.

About file sizes: NotePad+ has a theoretical limit on file sizes of 20 MB. However, loading files over 500 kB to 1 MB may be slow. If you frequently need to open files that are in that range (or larger), NotePad+ may not be the best editor for your needs. For files up to somewhere in the 500-1000 kB range however (depending on your particular system and perception of speed), NotePad+ is fine. 

Opening in a running instance does not work if you use Send-To (when NotePad+ is in the Send-To Folder) or when dropping on the executable (shortcut). Funny enough, Win95 does not use DDE when you do this. I've not yet found a way to solve this in a nice way, but if I do, it will be implemented. Meanwhile, you can easily drop on the running instance by holding the file(s) over the Icon in the Task bar and drop the load on NotePad+ after it pops up.


5. Credits:
-----------
Thanks to:

- All the people who have given me suggestions, bug-reports and fan mail.

Used Components created by:

- Envy Technologies (About95)
- Erik C. Nielsen (TFileDrag)
- Bill Menees (TLinePrinter)
- Brad Stowers (TPageSetupDialog, TBrowseDirectory)
- Patrick Brisacier and Jean-Fabien Connault (TPBShellLink)


6. History:
-----------
Versions with an increased number at the end of the version number are mainly bug fixes. Versions with additional functionality will have an increased number directly after the dot.

For example, 1.1 has more functionality than 1.02, while 1.02 has no significant extra functionality over 1.01. You can always check out the NotePad+ Home Page for the latest version.

 1.0    September 17 1996:
 -------------------------
First release.


 1.01   September 18 1996:
 -------------------------
Fixes 'Invalid data type for Alternative' error.


 1.02   September 25 1996:
 -------------------------
Fixes bug in Fonts/Colors preferences. NotePad+ would change fonts/colors for current session of application even though the Preferences box was cancelled after you had messed around with the Fonts/Colors preferences. (You would only have noticed this if you used the fixed/proportional switch after closing the Preferences box.)

Fixes bug where Find function would not highlight first string found (very irritating!).

About dialog now checks under what OS the application is running. Skips System Resources when running under NT (NT has unlimited system resources). NotePad+ is now fully NT capable.
                         
Reduced program executable's size by >70kB(!) by removing an un-needed source code unit that Delphi had automatically added when I was trying some things out before the first release.

Several other (minor) bug-fixes and adjustments. Polished the program a bit more.


 1.1   October 30 1996:
 ----------------------
- Bug fixes:
                         
A new file will now be created at start-up if this option is checked in the Preferences. This bug unfortunately sneaked into version 1.02. Interesting to note is that this bug is by far the most reported one. :)

Send box now displays text as it should when the Windows Display setting is set to large fonts. Changed a number of things in the Properties box and other places in order to solve the problems that some of you are having when running NotePad+ while Windows is set to use Large fonts. I'm not able to reproduce these problems, but the screen shots you people sent me where enough to convince me that this is a real problem. Since I'm not able to test the results of the changes I made (the problems with Large fonts strangely enough don't occur on my system) I urge you to give feedback on the results.

Changed behaviour of Replace button in Replace Dialog. Instead of finding and immediately replacing the text to find, it will now find the text on the first click, and replace it on the second.

I made some changes to the program to prevent the irritating updating of the Windows desktop that occurred when opening and creating files.

The Open Dialog will now only follow the path (when 'Follows Path after Open' is checked in your Preferences) when the Open Dialog itself is used to open a file. Opening of files by, for instance, doubleclicking will leave the Open Dialog path to what it is.


- Added/changed functions:

Made optimizations to speed up the creation of the edit windows, maximizing/restoring windows and switching between files.

Double clicking on a file while NotePad+ is already running will now result in opening of the file in the already running instance of NotePad+ instead of a new instance that would be started.
To make the above behaviour possible, I made NotePad+ what's technically called a DDE-server. Explorer now communicates with a running instance of NotePad+. It was necessary that the associated file types with the original Notepad were updated to implement DDE. That's why I made an Associations tab sheet in the Preferences box where you can associate files with NotePad+ in an easy way.

Dropping a file on the executable (shortcut) or using Send-To, will now fetch the long name for the directory (as was already done for the file name in these cases). Win95 seems to pass the DOS file name and path when you drop a file on the executable (shortcut) icon. You should never ever see a DOS file name or path in NotePad+ now (except for the Properties box where the DOS file name is deliberately shown :).

Under the File menu are now options to save selected text as a file, to create a shortcut of the active file and to open the containing folder of the active file.

You can now select for yourself how many Recent Files will be kept track of, with a maximum of 16. Created a sub menu for the Recent File list to prevent the File menu from cluttering. Recent File menu now shows only file names, full paths are shown in the status bar when moving over a file name in the Recent File list. Let me know if you like this (I do :). An entry is now added to the recent file menu after a file is closed, instead of after it's opened.

Changed status bar font from Arial to the better readable MS Sans Serif font. First item in status bar now resizes with program window.

You can now decide for yourself whether window position, size and state (maximized/restored) will be saved after closing. It may come in handy to uncheck this option after you've found your 'perfect' window settings.

In the Fonts & Colors box, you are now able to select the Standard Windows Color for the elements (these are the colors as defined in the Windows Display properties under the Appearance tab). So if you have Windows set up so that your windows have a yellow background with red characters (yuck! just an example :), NotePad+ will follow this behaviour when you set your colors to Window Colors.
And you can now use any color your Windows supports, using the Color Palette that was added in this version.

Added a box where you can define your own Open- and Save dialog filters. Saving a file using the Save As function will save with the extension as defined in the selected filter.

Added a Page Setup dialog and a new Printing component. This will let you set margins and print accordingly. I've had reports that NotePad+ produced a division by zero error when printing under NT, I hope this will be solved now with the new Printing component.

Choose your own margin size for the edit windows. Text just looks better when there's a small margin on the left.

E-mail the author, or visit the NotePad+ Home Page by just clicking an item under the Help menu.


 1.11  October 31 1996:
 ----------------------
- Bug fixes:

Some fixes were already in version 1.1. I worked all day long fixing problems and uploaded newer 1.1's when something was fixed. There were also bugs that only appeared on some systems. It's really no fun at all to fix something that doesn't happen on your own system.  In fact, it feels like an impossible task. But I've been working on it today and fortunately, these problem seem to be solved now:

Some people were unable to add text to a document. Didn't happen on my system and a lot of other systems, so very hard to fix. I know, it must be very strange to hear the author of a text editor say: 'Editing now works' :-) But then again, as I said before, it didn't happen here and a lot of other people didn't experience this problem either.

The large toolbar/status bar problem finally solved. Toolbar buttons and status bar font now appear at normal sizes on systems that have the Windows Display properties set to use large fonts. Also didn't happen on my system and a lot of other systems, so very hard to fix (it comes down to just try all kinds of things and ask if it works).

The following bugs did actually occur on my system:

When creating a file, maximizing it, creating a file again and then restoring the files would cause the inactive edit window (the one in the back) to loose it's border icons (for maximizing, closing etc). Fixed it.

Opening files sometimes didn't work ('Could not open.' alike messages), when NotePad+ was started from within another program. This is fixed.

The screen font (name & size) is now used when printing.

The text 'Unchanged' in the Status bar stays after opening a file and will not disappear anymore.

Thanks for the quick reports people, I hope everybody is happy now.


7. License & Disclaimer:
------------------------
This version of NotePad+ is distributed as Freeware. This means you don't have to pay for this software, just enjoy it! You are not allowed to modify this software. You may distribute it by making it available on online-services and distribution CD's and/or other media (I would appreciate being notified if this program will be distributed on these media, for example on a Share/Freeware CD). You may not ask money for the program itself, only for the distribution of the program. Use of this program is at your own risk.

Rogier Meurs reserves the right to release future versions of NotePad+ not as Freeware. This means future version may become Shareware, that must be registered. Although future versions of NotePad+ may become Shareware, you may always use this version (1.11) for free for as long as you like.


Happy editing!

Rogier Meurs
Author of NotePad+
