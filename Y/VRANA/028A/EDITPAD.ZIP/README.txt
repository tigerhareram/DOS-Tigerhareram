  EDITPAD README
******************

Contents
========

  1. What is EditPad?
  2. Do I need to pay for EditPad?
  3. Where can I find the latest information on EditPad?
     How can I contact the author?
  4. How do I install EditPad?
  5. How do I uninstall EditPad?
  6. I sell freeware/shareware CD-ROMs.
     Can I put a copy of EditPad on them?



1. What is EditPad?
===================

EditPad is a replacement for the standard Windows NotePad.
EditPad requires Windows 95 or later to run. No additional DLLs or
whatever are required.

It has a few very interesting features:
  * EditPad can open as many files at a time as you want.
  * You change between the open files by clicking on their tabs.
    No hassle with heaps of overlapping windows.
  * If you run EditPad again when their is already an instance running,
    the file(s) you wish to edit will be opened by the existing EditPad
    window.
    This means there will be at most one EditPad window open,
    which will save you from a lot of task switching.
  * Of course, if you do need more instances, simply pick View|New
    editor from the menu.
  * If you wish, the EditPad window stays on top of all other windows
  * Block functions:
    Save parts of your text to disk
    Insert a file in the current text
  * Specify many print settings: font, margins, headers/footers, etc.
  * Reopen menu that lists the last 16 files opened.
  * Configure the open and save dialog file filters
  * MAPI support
  * Easy and working installation and uninstallation (see below)
  * It's almost free! (see below)
  * ...



2. Do I need to pay for EditPad?
================================

EditPad is copyright (C) 1996, by Jan Goyvaerts.

The software (EditPad) is provided "as is". In no event shall I, the
author, be liable for any consequential, special, incidental or
indirect damages of any kind arising out of the delivery, performance
or use of this software. This software has been written with great care
but I do not warrant that the software is error free.
You may not attempt to reverse compile, modify, translate or
disassemble the software in whole or in part.

You may freely give copies of EditPad to others, as long as the
software is unmodified. You may not change a single bit,
you may not exclude any files or add any to the package. (There's only
one file: EditPad.exe)
You may not charge any money for the copying and/or distribution of
EditPad.

EditPad is postcardware. You are allowed to install EditPad and to try
it out for a short while (a week or two), but if you want to continue
using it you must register it with the author.
You can register by sending a postcard to the address below. The
postcard should be from your home town so I can see how far EditPad 
spreads. If your town is too small to have postcards, send one 
form your province, state or country.
Electronic postcards and the like are not accepted. You have to send
a real one through snail-mail. I collect them.
Postcards also have pretty pictures on them. An oversized business-card 
is not a postcard.

After your postcard has arrived, you are allowed to use EditPad for as
long and as much as you want, without any other cost. You also have the
right then to update your copy of EditPad when new versions come out.
If you mention you email address on the postcard, I will send you a 
message when I receive your postcard.

Please note that registration is strictly personal. Everyone who uses
EditPad has to register, even if someone else installed it on your
computer or if you found it on some CD-ROM you bought. (You payed for
the CD, not for EditPad.)
Even if you use EditPad (but you'd rather not) because your boss wants
you to, you have to register.

Even if EditPad seems to be a simple application, writing it was not a 
very easy task. So if you like it, send me a nice postcard. If everyone 
would say "thank you" when someone else did or said something nice, 
this world would be a much better place.

Send your postcards to this address:

   Jan Goyvaerts
   Lerrekensstraat 5
   2220 Heist-op-den-Berg
      Belgium



3. Where can I find the latest information on EditPad?
   How can I contact the author?
======================================================

Feel free to visit my home page at http://www.tornado.be/~johnfg/
to gather the latest news on EditPad.

If you wish to receive an email message when a new version of EditPad 
comes out, feel free to subscribe to my mailing list by filling out the 
form on my home page.

You can contact the author by sending email to johnfg@tornado.be


4. How do I install EditPad?
============================

Simply put a copy of EditPad.exe on your hard disk somewhere
(eg: c:\Program Files) and run it.

A dialog box displaying this text will pop up. Read the entire text
carefully (you're probably doing so right now).
If you agree with it, check the little box below and click on the
button below.
If you do not agree with it, click on the button below to terminate
EditPad.

If you agreed, you will see the EditPad window with an empty text
opened, named "Untitled".
Don't bother about it, just pick Options|Configure from the menu.

A small dialog box will pop up. Check the options you like
and click on OK.

Here's a little more information on the options:
  * Default program for text files:
      Launch EditPad whenever you double-click on a .txt file
      in the Windows Explorer.
    * Use EditPad icon:
        Display EditPad's icon next to .txt files in the Windows
        Explorer.
  * In Send To menu:
      Put a shortcut to EditPad in the Send To menu.
      Then you can right-click on any file in the Explorer and pick
      EditPad from the Send To menu to edit the file with EditPad.
  * Icon on Desktop:
      Put a shortcut to EditPad on your desktop.
  * Icon in Start Menu:
      Put a shortcut to EditPad in the Start Menu
      (menu that appears when you hit the Start button).
  * Icon in Programs menu:
      Put a shortcut to EditPad in the Programs menu of the Start Menu.

That's all there is to it.

If you change your mind later about which options you like, simply
repeat the above procedure.

If you wish to replace the version of EditPad you have currently 
installed with a newer one, simply replace the old EditPad.exe on your 
hard disk with the new one. No other actions are necessary.



5. How do I uninstall EditPad?
==============================

There should never be any reason to do so. If you wish to update 
EditPad to the latest version, simply replace the old EditPad.exe on 
your hard disk with the new one.
However, uninstalling EditPad is an easy thing to do.

Run EditPad and pick Options|Configure from the menu.

Click on the Uninstall button in the dialog box that popus up. This
will remove all shortcuts that EditPad installed and will also clean
any information stored in the registry by EditPad.

Close EditPad and delete EditPad.exe from your hard disk.

RIP.



6. I sell freeware/shareware CD-ROMs.
   Can I put a copy of EditPad on them?
=======================================

If you read this agreement carefully, you know you are not allowed to 
charge money for the distribution of EditPad. In other words: you can't 
put it on a CD that must be payed for.

However, if you contact me (johnfg@tornado.be) before putting EditPad 
on a CD I can give you permission to do so. This way you can also be 
sure that you are including the latest version of EditPad. You will 
also have to mention that the people who buy the CD, pay for the CD and 
not for EditPad. If they use it, they still have to register by sending 
a postcard.

Though I cannot oblige you to do so, if you put EditPad on a CD-ROM, I 
would really like to recieve a free copy of that CD.