Easy Edit for Windows95 v1.05

Copyright � 1996 Jason B. Franklin All Rights Reserved

Easy Edit for Windows95 - Easy to use text 
editor with built in HTML functions. Has no 
file size limit, built in spell checker, multiple 
document edit, HTML tags with the click of a 
mouse button, and a  tool bar. Can also print
text into a "booklet" format to conserve paper.
This program is not just a HTML editor, it's a 
great replacement for Windows Notepad.


Requirments :	Windows95 - 1.5 Megs Diskspace - 8 MB Memory


Installation :

Run setup and you will be guided through installation.
An icon for Easy Edit will be added to your 
start menu .


De-Installation :

Select Add/Remove Programs from the Control Panel.
Select Easy Edit and click Add/Remove.


Program Registration :

If you find this program useful, please register it. With registration
you will receive a code that will disable ALL the NAG / BEG screens 
and will display the fact that it is registered in the program window.


Send $15.00 check or money order to : 	     Jason Franklin
  				                10303 E. Peakview Ave. #102
  				       	           Englewood, CO 80111


Credit Card orders are $20.00 	    : http://www.csn.net/~franklin/easy.html	
    Register On-Line			   




If you have any questions about this product please feel free
to contact me at franklin@lynx.csn.net.


The programs home page is at 

http://www.csn.net/~franklin/easy.html


Your comments are welcome at any time.

Thank you for your support!


  
