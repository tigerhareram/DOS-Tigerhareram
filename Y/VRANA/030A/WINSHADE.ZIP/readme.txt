WinShade 2.11

What is WinShade?

WinShade is a Windows 95/NT 4 desktop utility that gives you control over your
windows.  With WinShade you can assign various commands to mouse button clicks 
that occur on window title bars.  These commands include minimize, maximize, 
"Rollup/Unroll", "Send to bottom", and "Keep on top".  The "Rollup/Unroll" command 
allows you to "roll up" the window into its title bar, leaving only a thin horizontal 
window on the desktop.  You can click back on the rolled-up window's title bar at 
any time to restore the window to its previous dimensions.  The "Send to bottom" 
feature allows you to send any window to the bottom of the window stack, while the 
"Keep on top" command will make a window stay on top of all the other windows.  
WinShade works with almost all windows, including dialog boxes, child windows, and 
maximized windows.  Customizable options include the ablity to remove the tray icon, 
change the way various commands are activated, and assign sounds and hot keys.  
WinShade comes with a complete help system and can easily be installed or removed.


How do I install it?

It is recommended that you use the supplied Setup.exe application to install WinShade.  
The Control Panel Add/Remove Programs applet will allow you to uninstall WinShade at a 
future date if you wish to do so.  If you have a previous version of WinShade, you 
should install this version over the old version.  However, you must first exit any 
previous version of WinShade before running Setup.exe.


How do I register?

Registration information and a Registration Form is included in the WinShade.hlp file.