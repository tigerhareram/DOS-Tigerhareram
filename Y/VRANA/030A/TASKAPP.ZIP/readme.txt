TaskApp Version 2.0

-What is TaskApp?
TaskApp is a free, simple to use Windows 95 program which will minimize in the Windows 95 tray. 
A right click will activate a popup menu, which allow you to launch everything you want,
which is launchable in Windows 95 (executables, folders, etc.). It also gives you access to
your drives (option)

-What's new?????
The settings menu has now a checkbox called 'Show icons'.
If this is selected, the popup menu will show the icons for the programs.
The TaskApp window is now resizable.
It also won't stay on top any longer.
You can add command parameter lines to your programs.
You can change the path to the program.
If you add lots of items, the popup will split in two or more columns.
The drive menu can also show the size and free space of the drives.

-How do I activate the popup?
Rightclick the icon in the Windows 95 tray.

-How do I add items?
Choose settings from the popup. Drag your files, applications, documents in the listview. 
Choose Apply or OK to confirm your new settings. 
From now on it will appear in the popupmenu.

-How do I delete items?
Choose settings, rightclick the item you want to delete, choose delete.
Or choose settings, select the item, choose the second button in the toolbar

-How do I rename items?
Choose settings, rightclick the item you want to rename, choose rename, change the name. 
Choose apply.

-How do I launch items.
Choose the item from the popupmenu.
Or choose settings, rightclick the item you want to launch, choose launch
Or choose settings, select the item, choose the first button in the toolbar

-What can TaskApp launch?
Everything which is launchable by Windows 95.
Where come the icons from.
These are the icons which Windows 95 associates with the item.

-How do I add command line parameters 
Choose settings, rightclick the item. Choose Edit and enter your arguments.

-How do I edit the path to a program.
Choose settings, rightclick the item. Choose Edit and enter your arguments.
(Note: TaskApp doesn't check if your path is alright!)

-Who made TaskApp
TaskApp was designed and written by Victor Heijke
email : vix@bedrijfsnet.nl


-Know Bugs
You cannot drag items from the 'my computer' window. This is because normally
Windows 95 doesn't accept any dragging from this window (Have you ever noticed the
'You cannot move or copy this item to this location, would you create a shortcut instead' message?)
That's the reason why I added the Show Drives Checkbox.
If you insist on having something from this window in the menu, create a shortcut to this drive somewhere
on your computer, and add this shortcut to TaskApp.

The popupmenu sometimes doesn't dissappear immediately when clicking outside the popup.
I don't know how to fix it. Anyone with an idea ??? (Delphi 2.0)


-Todo for next releases.
Fix the bugs.
Create a normal help file. Sorry I hate to do that.


-Thanks
to all the people who send me mail about TaskApp.
Almost everyone was positive, so it gives me double pleasure to refine TaskApp.
Specially thanks to the people who told me about the bugs or gave me some good ideas.
Especially thanks to Juul Mulder, who gave me some help on the icons. 