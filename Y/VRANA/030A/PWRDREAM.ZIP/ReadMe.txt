      Name: PowerDREAM (v2.02) for Win95

   Purpose: A highly configurable shell productivity menu.

To install: 1) Decompress the zip file into a temporary directory.

            2) Run PwrDREAM.exe

            3) Delete the files you decompressed.
                                        
    Status: Shareware - freely distributable.


Contact me on eirhanse@online.no
                                                         
---------------------------------

If you experience problems with the installation try the following:
   
   Right-click the file PwrDREAM.inf and choose install.   

   Check to see if the menu works by clicking an icon on the desktop, 
   if at this point there is a problem, do the following:

   Go directly to Add / Remove programs in the Control Panel and
   uninstall PowerDREAM.                                

   Run PwrDREAM.exe

You might have to restart win95 but the installation should now be 
completed successfully.