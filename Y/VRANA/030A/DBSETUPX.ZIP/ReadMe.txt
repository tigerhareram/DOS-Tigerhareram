
DeskBar for Windows 95 and Windows NT 4.0
Version 3.12
Copyright � 1994-1996 Burrell Software Enterprises
All rights reserved.


Introducing DeskBar
-------------------
DeskBar is the consummate toolbar for your Windows 95 and Windows NT 4.0 desktop.
More than just your average strip of buttons which launch your favorite
programs, DeskBar has 9 special buttons which bring all of the exciting
features of the Explorer shell to your bars.  In addition, DeskBar can function
just like the system taskbar by docking to any side of the screen and
optionally autohiding.

If you're like me, you've been collecting shareware and freeware applications
that enhance your Explorer shell since the release of Windows 95.  You've got a
tray icon for starting your screen saver, one for changing your wallpaper,
another one for quickly exiting Windows, yet another for allowing you access to
your desktop icons should they be covered.  You even have a program that lets
you add tray icons at will to launch other programs (a toolbar in the tray, so
to speak).  After collecting this many of these utilities, your tray takes up
1/3 of the taskbar and your startup group runs 10 different applications.  The
system is lower on memory and slower for it.

With DeskBar, you can ditch all of these applications, and their various
shareware registration fees and nag screens, and settle on one utility to
organize your desktop.  Create a bar with shortcuts to your favorite Internet
apps and websites; create one that has all of the items from the Start Menu on
it; create another bar that has your Office applications and documents on it
(to replace the buggy Microsoft Office Shortcut Bar).  Dock one up top, another
on the right.  Float one along the edge.  One has small icons, the others have
large icons.

The point here is that you have the ultimate desktop organization tool in
DeskBar.  Play with it, beat on it, and no doubt you'll end up agreeing that
this utility is what you've been waiting for to enhance your computing
experience!

If you know anything at all about building software applications, you'll
recognize that DeskBar is implemented with the latest techniques in building
Windows applications.  For all of its functionality, DeskBar tips the scales at
under 500K, and makes tight, robust use of the C++ language and MFC class
library.  All of the buttons are based on an ActiveX control, and the bar
itself is an ActiveX container.  This means that as ActiveX heats up the
Internet and your operating system, DeskBar will be there to host the fire.


Installing DeskBar
------------------
To begin the installation, run Setup.exe and follow the Setup Wizard's prompts.
Setup will install the following files into your DeskBar destination folder:

DESKBAR.EXE     main program
DBREMOVE.EXE    DeskBar uninstall program
DBCOMPS.OCX     DeskBar components file
DBSHLEXT.DLL    DeskBar shell extension library
DESKBAR.HLP     help file
DESKBAR.CNT     help contents file
SAMPLE.BAR      sample bar
LAYOUT95.LYT    sample layout for Windows 95
LAYOUTNT.LYT    sample layout for Windows NT4
DBTIPS.TXT      tips file
ORDER.TXT       order form

Setup will install the following files into your Windows system directory if
they are needed:

MFC42.DLL    v4.2.6256   Microsoft Foundation Classes library
MSVCRT.DLL   v4.20.6164  Microsoft Visual C++ runtime library
OLEPRO32.DLL v4.2.6068   OLE property page library

DeskBar will only run on Windows 95 or Windows NT 4.0 and later versions.


Uninstalling DeskBar
--------------------
To uninstall DeskBar, run the "Add/Remove Programs" applet in Control Panel.
Select "DeskBar" from the list and click the "Add/Remove" button.


Registration
------------
DeskBar is built from the most advanced software technologies currently
available, and will continue to improve as the technology moves forward.  Your
registration fee will help enable DeskBar to remain at the forefront of
technology and make you more productive.

As a registered user, you will receive:
	- A registration code that enables you to have unlimited bars and unlimited
	  buttons.
	- Your name and organization on the splash screen and About page.
	- Free maintenance* releases. 
	- Free technical support via e-mail.
	- An eager ear for your comments and suggestions for improvement.

* Burrell Software Enterprises reserves the right to charge an upgrade fee for
major new releases.

The single user registration fee for DeskBar is $25.00 (US dollars).

For site license arrangements, contact Burrell Software Enterprises.

Ordering by check:
    To order by check, complete and send the completed order form ORDER.TXT and
	a check to the address below. Payment must be in US dollars drawn on a US
	bank, or you can send cashier's checks or international postal money orders
	in US dollars.

Ordering by CompuServe:
    To have the registration fee added to your CompuServe bill, use the
	CompuServe command GO SWREG and follow the menus. DeskBar's CompuServe
	registration ID	is 2220.

Ordering by credit card:
    You can order with MC, Visa, Amex, or Discover from Public (software)
	Library by calling 800-2424-PsL or 713-524-6394 or by FAX to 713-524-6398
	or by e-mail to 71355.470@compuserve.com. You can also mail credit card
	orders to PsL at P.O.Box 35705, Houston, TX 77235-5705.

	DeskBar's PsL registration ID is 14896.

    THE ABOVE NUMBERS ARE FOR CREDIT CARD ORDERS ONLY.
    THE AUTHOR OF THIS PROGRAM CANNOT BE REACHED AT THESE NUMBERS.

    Any questions about the status of the shipment of the order, refunds,
	registration options, product details, technical support, volume discounts,
    dealer pricing, site licenses, non-credit card orders, etc, must be
	directed to Burrell Software Enterprises.

Upon receipt of your registration fee, you will be sent your registration
code, along with instructions for registering your copy of DeskBar.

Invoices will be sent out on request.


Contacting the Author
---------------------
I can be reached at the following addresses:

Patrick M. Burrell
Burrell Software Enterprises
4718 Millhaven Dr. SE
Kentwood, MI 49548

Web URL:	www.iserv.net/~burrell
Internet:   burrell@iserv.net
CompuServe:	71163,2001


Thank you for your interest in DeskBar, and I hope to thank you soon for your
support!

