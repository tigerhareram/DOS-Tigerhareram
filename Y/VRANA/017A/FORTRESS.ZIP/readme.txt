The level (FORTRESS.BSP) must be copied in the quake/id1/maps-directory. Start it with MAP FORTRESS
out of the console (by pressing the ^-key).<br><br>

---------------------------------------------------------------

ATTENTION :
Because a fort must be outside (else it is no fort), the level consists of a huge room. That�s what
QUAKE does not like. In order not to see DISAPPEARING TEXTURES or GREY PLANES, you have to change two
QUAKE-C-variables. Simply type the following two lines in the console (by pressing the ^-key):<br>

R_MAXSURFS 1000<br>
R_MAXEDGES 2700<br>

frag it! And: DEATHMATCH 2 rulez!

								Kilian
----------------------------------------------------------------

put today's date here
================================================================
Title                   : FORTRESS OF DEATH
Filename                : FORTRESS
Author                  : KILIAN WENIGER
Email Address           : k.weniger@tu-bs.de
Description             : a cool deathmatch fort!




               Check out the Thred homepage at:
              http://www.visi.com/~jlowell/thred
================================================================

* Play Information *

Single Player           : No
Cooperative             : No
Deathmatch              : YES
Difficulty Settings     : No
New Sounds              : No
New Graphics            : No
New Music               : No
Demos Replaced          : None

* Construction *

Base                    : New level from scratch
Editor(s) used          : Thred
Known Bugs              : DISAPPEARING TEXTURES -> change c-vars, look above!
Build Time              : about 3 weeks

Texture Wad used        : Base

Compile machine         : iP133, 32MB-RAM
QBSP Time               : 1000 sec.
Light Time              : 600 sec
VIS (-level 4) Time     : about 30  hours

Brushes                 : about 600
Entities                : about 126
Models                  : 1

* Other Info *

change c-vars!!! Look above!

* Copyright / Permissions *

Authors MAY NOT use this level as a base to build additional
levels.

This BSP may be distributed ONLY over the Internet and/or BBS systems.
You are NOT authorized to put this BSP on any CD or distribute it in
any way without my permission.

* THRED LISCENSE INFORMATION *

This map was made with Thred. It is acceptable to distribute this
map over the Internet and BBS systems for free. It is not
acceptable to play this map on a commercial Internet server.
It is also not acceptable to charge for this map in any way
or charge for distribution of this map. This includes CD-ROM
collections of all kinds.