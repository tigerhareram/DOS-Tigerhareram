@echo off
echo Copying some system files to your %windir%\system directory...

copy *.DLL %windir%\system
copy *.oc? %windir%\system

echo .
echo Registering the system files...

regocx32 %windir%\system\HTTPCT.OCX
regocx32 %windir%\system\tabctl32.OCX
regocx32 %windir%\system\comctl32.ocx
regocx32 %windir%\system\VB40032.DLL
regocx32 %windir%\system\nmocod.dll
regocx32 %windir%\system\nmsckn.dll
regocx32 %windir%\system\nmorenu.dll
regocx32 %windir%\system\olepro32.dll
regocx32 %windir%\system\mfc40.dll

echo .
echo Copying PIF to %windir%\pif directory...
mkdir %windir%\pif
copy qping.pif %windir%\pif


echo .
echo Done! Enjoy QuakeNet...
