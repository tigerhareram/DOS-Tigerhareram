ping -n 1 %1 %2 %3 %4 > qping.tmp
exit
