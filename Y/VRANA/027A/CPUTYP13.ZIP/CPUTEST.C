#include <stdio.h>

int CPUType(void);
int FPUType(void);

char *cpunames[]={"","8086/8088/80186/80188","80286","80386","80486",
  "80586 Pentium","80686 P6","80786 or higher"};
char *fpunames[]={"None","8087","80287","80387","80487 (Internal)","Internal"};

void main()
{printf("CPU Generation Detection\n1995 by XMAS coding (Dominik Freche)\n");
 printf("CPUTYPE.ASM v1.3\n!!!!! THIS SOURCECODE IS FREEWARE !!!!!\n");
 printf("CPU Type: %s\n",cpunames[CPUType()]);
 printf("FPU Type: %s\n",fpunames[FPUType()]);
}
