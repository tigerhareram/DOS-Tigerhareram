                        File Name Juggler v1.21 beta
                        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                      The Ultimate Batch Renaming Tool
                             for Windows NT/95


Have you ever:
-Had to rename big lists of files manually?
-Trashed a directory because you typed an incorrect rename command?
-Been frustrated by the confusing and mind-taxing command-line "REN" command?
-Etc, etc?

Of course YES!  Everybody has to face those damn situations one day. But the
key to your freedom and power has just been forged, right out of the
blacksmith's workshop. It's named... File Name Juggler! Crafted for power
and flexibility for the professional system administrator, but also designed
with a very intuitive and easy to use interface for anybody at home who may
need to handle their file names under Windows 95 or Windows NT.


Features
~~~~~~~~
- Rename To: Performs complex renaming operations in a VERY intuitive way.
- Standardize: Makes all your files have the same capitalization style.
- Reorder Numerals: Reorders and reformats the numerals of your file names.
- Batch Commands: Generates a batch file from a list of file names, with
                  other options...
- Preview: Gives you a glimpse to what files will look like, before actually
           renaming them!
- Undo: Restores file names to their original state.  No messes anymore! :)
- Full support for long file names.
- And much more!!!  (Refer to File Name Juggler's on-line help)


Installation
~~~~~~~~~~~~
To install this application, just copy all files to a unique directory (ex.
C:\Juggler) and that's all!


This application is Shareware
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
You have the great opportunity to evaluate this application for a 30 days
trial period.  If you like and want to keep using this application, you have
to register.  By registering, you will receive a fully functionnal,
not-time-limited version, as well as totally free bug fixes and patches for
this version, as they become available.  It also entitles you for low-cost
updates for future releases, as well as free Email support and information
on other Antares Productions' releases.

To register, just print out the REGISTER.TXT file, fill and mail it with a
cheque or money-order of the appropriate amount to our registration address
given below.

Please, make cheques payable to Mathieu Frenette. Thanks in advance.


Our Addresses
~~~~~~~~~~~~~
Registration :     Antares Prod.
                   Attn/ Mathieu Frenette
                   269 Brunelle
                   Bonsecours, QC
                   Canada
                   J0E 1H0

Email:             juggler@interlinx.qc.ca

FNJ's Page :       http://www.interlinx.qc.ca/~midk/juggler

Fax :              514-532-4129


File Name Juggler(TM)
Copyright (C)1996-97
Antares Productions
(Mathieu Frenette)
All Rights Reserved