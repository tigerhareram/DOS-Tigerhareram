Chgname 2.0

Functionality:
Chgname is a fast 32-bit file management program
designed for Windows95/NT which renames, changes
the date and attributes of up to 32767 files. The 
new filenames are composed by wildcards or 
enumeration. The files are either moved into 
one directory, left where they are or copied into 
one single directory. Chgname is ideal for everyone
who have demanding tasks which includes keeping
order in large number of for example data files.

The renaming process offers quite a lot of flexibility
with both wildcards (* and ?) and enumeration
capabilities. When enumerating large number of files,
the user specifies a prefix and the program enumerates
the files from any number (not more than 9 digits)
with a step of 1 or more. The user also specifies the
minimum number of digits the number should have,
so that 002 comes before 010 and so on.

Chgname changes all available date and times
(creation, last modified, last accessed) and may alter
the file attributes (Read Only, Archive, System,
Hidden).

Example:
Renaming some .jpg files with enumeration from 10,
step 5 and minimum 5 digits. Prefix is "Pic", extension
is unchanged:
	Pic00010.jpg
	Pic00015.jpg
	Pic00020.jpg
	Pic00025.jpg ... etc.

Installation:
Automatic setup program.


For further information, see the included help file
and the about screen in Chgname.


About Chgname 2.0
- Programmed by Kjetil L. Nyg�rd, 1997
	E-mail: k.l.nygard@hfstud.uio.no
	Http: http://www.uio.no/~kln/
	Download: http://www.uio.no/~kln/Download/
- Written and Compiled in Borland Delphi 2.0

Distribution:
This software is FREEWARE.
This software may be freely copied and distributed
by anyone and included in NON-PROFIT software
collections provided that THE COMPLETE SETUP PACKAGE
is included!


No guarantee.
