
CatFish                       Version 1.5                       December, 1996
==============================================================================


DESCRIPTION

    CatFish is a disk catalog browser.  It allows you to save snapshots of the
    directory/file structure of your disks and to search through them at any
    time.  The catalog files maintained by CatFish are very compact and fast,
    and can easily handle the huge directory trees often found on large disks,
    removable disks, and CD-ROMs.  CatFish will calculate total subdirectory
    sizes, and lists the date of the newest file found inside each directory.

    You can search all catalogs by file name (wildcards), size, and/or date.
    When used in Windows 95, CatFish will recognize and store long file names.
    Furthermore, CatFish can be used as an application or document launcher.

    New in 1.5:  Quick rescan (F5).  Wildcard searches.  Export to text file.
                 Accepts disks with > 10,000 files.  Can stop a long search.
                 Command-line option added to start up with the Find dialog.

    Best of all, CatFish is free.

    For the latest news, check the home page - http://purl.net/meta4/catfish
    Do you have a suggestion on how to further improve CatFish?  Let me know!


GETTING STARTED

    Using CatFish is easy, just start it up.  There is no installation, there
    are no DLLs, it runs on all Windows versions.  Support for long filenames
    is included for Windows 95, but catalogs themselves must have short names.

    When you start CatFish for the first time, it will give you a few tips.

    When you create catalog files, these will be placed in the same directory
    as CatFish (with a ".CF4" suffix).  If you move CatFish, you must move the
    catalogs as well, otherwise these catalogs will no longer be accessible.

    To have CatFish open with the "Find" dialog window, start it up using the
    command line "catfish.exe /f" (Win 3.1: program item, Win 95: properties).

    TIP: If you have a very large number of disks, just distribute all catalog
    files over several directories and put a copy of CatFish in each of them.


FOR SOFTWARE DEVELOPERS ONLY

    CatFish is based on the MetaKit library, a shareware C++ class library for
    persistent data structures.  The sources of CatFish and many other small
    sample programs are freely available as part of the MetaKit distribution.
    
    The MetaKit library is a portable developer toolkit for data storage and
    easy handling of structured objects and collections in C++.  If you need
    bulky/powerful database functions, look elsewhere, but if you need a small
    and portable library to store structured data, please check it out:

                http://purl.net/meta4/metakit

    If you are a C++ programmer interested in persistent storage, Winsock, or
    simple client/server applications for TCP/IP, you will probably find some
    useful code / ideas in MetaKit.  It even has a utility to create catalogs
    of remote FTP servers (yes, these catalogs can be browsed with CatFish).
    
    MetaKit registration is US$25, source code is $90 (multi-platform: $165).


DISTRIBUTION

    The CatFish utility is copyright Meta Four Software, NL.  You may use this
    free software for any purpose, as long as you leave all copyright notices
    in place and assume all risks for its use, regardless of the consequences.


CONTACT INFORMATION

    Jean-Claude Wippler          mailto:jcw@meta4.nl

    Meta Four Software             http://purl.net/meta4
    Meekrap oord 6
    3991 VE, Houten                 fax:+31 30 635 2337
    The Netherlands
