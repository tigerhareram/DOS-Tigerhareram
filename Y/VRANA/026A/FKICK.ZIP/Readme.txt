
    FileKick v1.5b - Directory List and File Manager
    Copyright 1995 FileTrak(TM) Software, Inc.
    All rights reserved.
    Last revised: 02/08/97

    NOTE: While opened, FileKick is visible only as a dialog box.
    When you close the dialog, the application is still running
    in its minimized state and will show up as an icon in Win3.x
    or as a taskbar button in Win95. To close the app, open the
    system menu from the MINIMIZED state and select "close".

    =============================================================
    This file contains release notes that supplement FileKick's
    Help file and accompanying software.

    Information is presented on the following topics:

    Section   Description
    -------   ---------------------------------------------------
       1      SYSTEM REQUIREMENTS

       2      GETTING STARTED

       3      DOCUMENTATION

       4      UNINSTALLING

       5      TRIAL VERSION

       6      WIN95 TASKBAR

       7      DISPLAY OPTIMIZATION

       8      VERSION HISTORY

    =============================================================
    1.  SYSTEM REQUIREMENTS
    =============================================================
    Personal computer with a 386 or higher processor running
    Microsoft Windows 3.1x, Windows 95 or Windows NT 3.51 or
    later operating system.

    4MB of memory needed and about 1.2 MB of disk space.

    VGA or higher resolution monitor.

    =============================================================
    2.  GETTING STARTED - run setup
    =============================================================
    a. Insert the FileKick diskette in a floppy disk drive.
                            -- or --
       switch to the temporary directory where you extracted the
       program files from the FKICK.ZIP archive file.

    b. From the Windows Program Manager or the Start button on the
       taskbar select the "Run..." menu command.

    c. When the Run dialog box appears, type A:SETUP in the command
       line box, where A: represents the letter of your floppy drive
                            -- or --
       run SETUP from the temporary ZIP extraction directory.

    d. Follow the installation instructions.

    Files are only installed in the specified destination directory.

    =============================================================
    3.  DOCUMENTATION
    =============================================================
    As of this time, all documentation is in the form of a help
    file which can be accessed from the FileKick program group
    after installation. The help file is not compressed, so you
    may look at it before installing the program either by first
    copying the file (FILEKICK.HLP) to your hard disk, or running
    it directly from the install disk.

    All screen illustrations were taken from a Windows 3.1
    environment.  The major difference observed in Win95 will be
    the lack of a "system" menu on the caption bar of the FileKick
    dialog.  This "system" or "control" menu is accessible in
    Win95 by clicking the caption bar with the right mouse button.

    Press the F1 key at any time while running FileKick to access
    complete context sensitive help.  Be sure to check out the
    Navigator help window which allows you to cross reference
    the main help file.

    FileKick introduces new concepts not currently available in
    other file managers - including filename paste, directory lists
    and tables.  We recommend that you first read "Using FileKick"
    in the help file for an introduction to these concepts.  Then
    examine the help screen for each of the program's four panels
    by clicking on each of the captured screen image's hot spots.

    If you don't like reading help files - try this:

        1. Go to the "Search panel".
        2. Use the "More" dialog to set the "Mingled list" option.
        3. Select "All local hard drives" in the "Where" field.
        4. Click on the "Find" button.

    When done, you will have a listing of all files on your system.

        5. Click on the "Save" icon in the button bar.
        6. Name and label your list, e.g. "*.* on all my local drives".

    You now can access this database of names in the future.

        7. Go to the "DirList" panel.
        8. Select your labeled entry from the "DirList" list box.
        9. Use the "Locate" field to find any file in the list.

    This list will save you countless cycles of searching all your
    drives like a mad person. While you're at it, why not
    create a list with all the ".hlp" files or another with all
    your "*.wav *.mid" files. And remember, once you locate a file
    you can apply any of the file management commands to it,
    including filename "Paste".

    This command gives you powerful browse dialog capabilities.

       10. Click on FileKick's caption bar minimize icon.
       11. Run Notepad and select the File menu open command.
       12. Hold down the [Alt+Shift] keys to hot key into FileKick.
       13. Select a text file to open and right mouse click on it.
       14. Click on the "Paste" command and bam you've got it!

    For a short tutorial on tables, follow the "Using Single Key
    Launch" help topic under "Questions and Answers". Once you
    set up a table, you'll be able to open documents with a
    single keystroke after activating FileKick.

    Check out the "Program Highlights" topic for an outline of
    other program capabilities including printing directory lists,
    analyzing hard disk usage, finding duplicate files and more.
    And remember, custom commands may be easily added to the pop-up
    file menu to tightly integrate new features into the program.

    If you have a Zip or SyQuest high capacity disk drive take a
    look at the "Backing up Files" topic.  The "Backup" command
    added in the v1.5 release can be used like any other file command
    on selected files of interest.

    =============================================================
    4.  UNINSTALLING
    =============================================================
    To remove FileKick permanently from your hard disk, run the
    program UNINSTAL.EXE from your install diskette.  This will
    remove all program files and associated program group.

    Follow the program instructions. When ready to delete files,
    you may choose the "Yes to All" button so that you won't
    have to confirm each file deletion.  After the program files
    have been deleted, you will have the option of removing
    any data files you may have accumulated in the FILEKICK\DATA
    directory.

    If you are using Windows 3.1 or Windows for Workgroups and are
    running a custom command shell, make sure Program manager is
    running when you run UNINSTAL.EXE.

    =============================================================
    5.  TRIAL VERSION
    =============================================================
    If you are using a trial version, your setup program will have
    already been branded with the "Trial Version" label.  This is
    a fully operational program except that it will expire on the
    date shown on the "About" dialog box.

    You have a temporary license to use the program. Please observe
    the license agreement terms, and refer to the help file for
    instructions and benefits of registering the software.

    Compuserve users may use the command "GO SWREG" to register
    FileKick using product ID# 10887.  See the help file or the
    order.txt file for additional ordering options.

    =============================================================
    6.  WIN95 TASKBAR
    =============================================================
    If you move the taskbar or change its properties after having
    started FileKick, you may briefly see a small inactive window
    move across the screen when the FileKick dialog is opened.
    This is the dialog's parent window and is of no consequence.
    The parent window will remain hidden if you restart the
    program after making the taskbar changes.

    =============================================================
    7.  DISPLAY OPTIMIZATION
    =============================================================
    The program list boxes are sized to fit an optimum number of
    lines when the display resolution is set to 96 pixels per inch.
    This normally corresponds to VGA or SVGA resolution or when
    using small fonts at 800x600 or 1024x768.  If you use large
    fonts, you will see fewer lines in a list box.

    =============================================================
    8.  VERSION HISTORY
    =============================================================
    Visit our home page at http://www.voicenet.com/~filetrak for
    the latest version files and information.

    1.1   12/27/95
          Initial Release.

    1.a   04/05/96
          Maintenance release.

    1.b   05/10/96
          Directory time field display 12:00a-1:00a fix.

    1.c   06/01/96
          Maintenance release.
          ASP Ombudsman certification.

    1.5   10/15/96
          NEW FEATURES:
          -  Disk Mirror Backup.
          -  Name Exclusion option in File Filter dialog.
          -  File menu uses both "Open" and "Run" commands.
          -  Separate history lists for each panel command.
          -  Full path Mkdir command.
          -  Label Disk command.
          -  Name-Filtered Xcopy.
          -  History list added to Xcopy "To:" field.
          -  Full path mkdir capabilities in "To:" field specifiers.
          -  File copy verification option.
          -  Hard Disk Usage help topic.
          -  Case sensitive short filename display in Win95.
          -  Option to display short filenames in upper case.
          -  Long filenames in printed directory lists.

          FIXES:
          -  Long filenames with blanks.
          -  Xcopy long filename creation.

    5.a   01/02/97
          Fix for truncated path display with long pathnames.

    5.b   02.08.97
          Fix for long filename enable on removable media.
    _____________________________________________________________

    With your support, we'll continue to enhance this program so
    that it meets your needs. Please let us know what you think.
    If you have questions or suggestions, send us e-mail in care
    of FileTrak Software at:

    Internet: filetrak@voicenet.com
    CIS mail: 104042,3470

    Thank you for trying our software.

    FileTrak Software, Inc.
    P.O. Box 006
    Pocopson, PA. 19366-006
    Phone: (610) 793-0589
