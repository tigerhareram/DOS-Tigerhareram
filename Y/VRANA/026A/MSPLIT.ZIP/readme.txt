MasterSplitter(TM) Help Contents

	1.0	License
	2.0	Introduction
	3.0	Installing and System Requirements
	4.0	Splitting Files
	5.0	Joining Files
	6.0	Comparing Files
	7.0	Ordering the Registered Version


1.0	License

VERSION INFORMATION:

MasterSplitter(TM) Version 1.0.
Copyright 1997 Tomasoft Corporation.
ALL RIGHTS RESERVED.

The dynamic link libraries that accompany this software are Coprighted by Microsoft Corporation.  
Also MSDOS, Microsoft Windows 3.1, Windows 95 and Windows NT are trademarks of Microsoft 
Corporation.


GOVERNING LAW:

This agreement shall be governed by the laws of Canada and the Province of Ontario.

DISCLAIMER OF WARRANTY:

THIS SOFTWARE AND INSTRUCTIONS ARE SOLD "AS IS" AND WITHOUT WARRANTIES AS 
TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER 
EXPRESSED OR IMPLIED.  BECAUSE OF THE VARIOUS HARDWARE AND SOFTWARE 
ENVIRONMENTS INTO WHICH THIS PROGRAM MAY BE PLACED, NO WARRANTY OF 
FITNESS FOR A PARTICULAR PURPOSE OF ANY KIND IS OFFERED.  GOOD DATA 
PROCESSING PROCEDURE DICTATES THAT ANY PROGRAM BE THOROUGHLY TESTED 
WITH NON-CRITICAL DATA BEFORE RELYING ON IT.  THE USER MUST ASSUME THE 
ENTIRE RISK OF USING THE PROGRAM.  IN ANY CASE LIABILITY WILL BE LIMITED 
EXCLUSIVELY TO THE AMOUNT OF MONEY THAT TOMASOFT CORPORATION RECEIVED 
FROM THE USER FOR THE USE OF THIS SOFTWARE PRODUCT.

SHAREWARE AND REGISTERED VERSION:

By using this software you indicate your acceptance of this software license agreement. . The 
shareware version is identified by the word "Unregistered" in the title bar and within the "About 
Box" of the applicaiton.  You may use this shareware version of this software on a trial basis 
for only 30 days. After that period of time you must purchase registered version of the software. 
The shareware or registered version may only be used on one computer at a time.  Storage on the 
computer is limited to one hard disk except where required for backup purposes.  The registered 
version may be stored on a network drive provided that sufficient licences have been purchased 
for the maximum number of concurrent users at that site.  The user may not modify or reverse 
engineer the software or documentation files contained in this version in any way.  The shareware
version may be redistributed to anyone else provided that all files associated with the shareware
version are provided together.  No monetary compensation may be accepted or requested by 
anyone for the distribution of this software without the expressed written permission 
of Tomasoft Corporation.



2.0	Introduction

The purpose of MasterSplitter(TM) is to split large files in order to move them via floppies or 
for transmission via E-mail. MasterSplitter(TM) is an ultra-fast 32 bit file splitter.  The file 
can either be a binary or a text file.  The program features an intuitive graphical user interface 
that makes splitting files easy.  

The program can also be easily be invoked directly from Windows Explorer by simply right-clicking
on any file and then selecting Send to MasterSplitter.

If you want to send the pieces to someone who doesn't have MasterSplitter(TM), simply check the 
"Create Reassemble Batch File" check box and a Win95/NT 4.0 batch file will automatically be 
created that you can send with the pieces to put it back together.

3.0	Installing and System Requirements

MasterSplitter(TM) has been tested under Microsoft Windows 95 and Windows NT 4.0 with a Intel 
Pentium based PC.  There is currently no version for MSDOS or Microsoft Windows 3.1 (Although 
there may be later).

To install MasterSplitter(TM), simply unpack the zip file and run the setup.exe program.  To 
uninstall it, select MasterSplitter(TM) from the Add/Remove Programs in the Control Panel 
(or run uninstal.exe).

4.0	Splitting Files

To start MasterSplitter(TM),, choose it from the Start Menu OR simply start it directly from Windows 
Explorer by simply right-clicking on any file and then selecting Send to MasterSplitter(TM),.  The 
split tab from MasterSplitter(TM),  controls the file splitting operation.  Enter the file name 
including the full path of the file you wish to split. If you can't recall the name, just select 
the browse button and you can find it.

Enter the size of the pieces you want to create.  The default corresponds to a full 3.5 high density 
diskette.  IF AND ONLY IF you're confident that you will no longer need the original file, select the 
check box for delete original when done.  I DON'T recommend doing this until your comfortable with 
using the program.

Be sure that you have free disk space at least equal to the size of file your splitting or it 
won't work.  When you're ready to go, click on the split button to get things started.

If you want to send the pieces to someone who doesn't have MasterSplitter(TM), simply check the 
"Create Reassemble Batch File" check box and a Win95 batch file will automatically be created that 
you can send with the pieces to put it back together.  You can use this same method to send the 
pieces to someone with MSDOS or Microsoft Windows 3.1, except that you'll have to edit the batch 
file to remove the quotes and make it compatible with short (8.3) file names of MSDOS.  The batch 
file will look something like this:

Lets say you have a file called "splitme" which you have split into three pieces.  Then the 
following batch file will recombine them:

Windows 95
copy /b "splitme.001" + "splitme.002" + "splitme.003"  "splitme"

MSDOS and Windows 3.1
copy /b splitme.001 + splitme.002 + splitme.003  splitme

Note that the last file is the destination and has no "+" sign in front of it.  The /b is required. 
(See the MSDOS help for details).



5.0	Joining Files

To start MasterSplitter(TM), choose it from the Start Menu.  The join tab from 
MasterSplitter(TM) controls the file splitting operation.  Enter the file name of the FIRST of the 
previously split pieces including the full path.  If you can't recall the name of a piece, just select 
the browse button and you can find it.

IF AND ONLY IF you're confident that you will no longer need the file pieces, select the check box for 
delete pieces when done.  I don't recommend doing this until your comfortable with using the 
program.

When you're ready to go, click on the join button to get things started.


6.0	Comparing Files

The compare tab from MasterSplitter(TM) controls the file comparison operation. You may want to use 
this as a double check before deleting anything.  Enter the original (BIG) file name including the 
full path of the file you wish to compare with its pieces. If you can't recall the name, just select 
the browse button and you can find it.

Enter the file name of the FIRST of the previously split pieces including the full path.  If you 
can't recall the name of a piece, just select the browse button and you can find it.

When you're ready to go, click on the compare button to get things started.




7.0	Ordering the Registered Version

Please send a $10 check or money order payable to "Tomasoft Corporation" by completing the 
following form.

Number of Copies		______   x   $10 Canadian ( or $8 US) 
Total		= 	______   x  1.08 (Prov. Tax)	=	______

For quantities greater than 30, write to Tomasoft Corporation at the address below (or by e-mail) 
to discuss site license arrangements.

Add $2.50 for shipping and handling if you require delivery by regular mail.


Method of shipment:	By E-mail: ___________________________ (Internet E-mail address)

Or By Regular Mail:						
(Fill in your Name and
Address Here)
____________________________________
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|                                   |
|___________________________________|


Mail the completed form and a cheque or money order to:

TomaSoft Corporation
33 Aristotle Drive
Richmond Hill, Ontario
Canada
L4S 1J7

Send other comments or suggestions can be sent by e-mail to tomasoft@worldy.com.
Check out http://www.worldy.com/~tomasoft for more information.
