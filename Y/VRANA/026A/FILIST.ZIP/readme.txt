FiLister for Windows 95\NT
=========================================================
FiLister v0.4 lists files in dir structures to an
outpuit file called liste.txt by dir\*.* or by 
dir\filename and full file information (see above)
(liste.txt: located on the temporary directory path).

NEW v0.4:   timer, subdir count

NEW v0.3e:  set FileProperties for all files in the list

NEW v0.2:   LedBar Activity
            FileTime info is now timezone independent


Required: CPU=486 / OS=Windows 95
other OS: Windows NT ???

Input:    search pattern like:
             e:\*.* , f:\* , c:\mydir\*.txt ...
             d:\mydir\myname.ext

          the first dialog button is used to select 
          a filename, you can then modify to search
          with a filter (*) in the edit control.

Output:   liste.txt: TAB delimited output on full info.
          path: see TEMP, or if no TEMP see TMP path
          setting in your pc system environment.
          (autoexec.bat, type >SET <RETURN> in DOS box)

Options:  full information, list sub directories
          size of liste.txt e.g. for 10371 files ~1,1MB
          

File Attributes/File Properties:

  Compressed = 2048  0x800
  Temporary  = 256   0x100
  Normal     = 128   0x80
  Archive    = 32    0x20
  Directory  = 16    0x10
  System     = 4     0x04
  Hidden     = 2     0x02
  ReadOnly   = 1     0x01

DateTime satmps: Creation, LastAccess, LastWrite


===============================================================
SHAREWARE_INFO: FiLister for Windows 95 
===============================================================

After a free 30 days evaluation time the shareware fee is 
5 US - dollar. Payment should be directed to following account:

US/International:
                        Sparkasse Dachau-Indersdorf
                                BIC:   DAHS DE 77
                     via Bayerische Landesbank M�nchen
                              SWIFT:   BYLA DE MM
                      U$-AccountNr.:   970 170 858
                        AccountName:   Roland Mundloch

in Germany:
                       Sparkasse Dachau-Indersdorf
                         IdNr.(BLZ):   700 515 40
                         AccountNr.:   89177
                   Owner of Account:   Roland Mundloch

Than send me your eMail address to get a valid registry key.


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Software License Agreement
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Use of the Filister program is contingent on your (herein-
after "Recipient") agreement to the following terms:

1. GRANT OF LICENSE.

Roland Mundloch, (r.m.) grants to Recipient a limited,
non-exclusive, nontransferable, royalty-free license to use one copy
of the executable code of the Product software on a single CPU
residing on Recipient's premises. All other rights are reserved to r.m..
Recipient shall not rent, lease, sell, sublicense, assign, or
otherwise transfer the Product, including any accompanying printed
materials. Recipient may not reverse engineer, decompile or
disassemble the Product except to the extent that this restriction is
expressly prohibited by applicable law. r.m. shall retain title and
all ownership rights to the Product.

2. PRODUCT MAINTENANCE.

r.m. is not obligated to provide maintenance or updates to Recipient
for the Product. However, any maintenance or updates provided by r.m.
shall be covered by this Agreement.

3. DISCLAIMER OF WARRANTY.

Product is deemed accepted by Recipient. The PRODUCT is provided AS IS
WITHOUT WARRANTY OF ANY KIND. TO THE MAXIMUM EXTENT PERMITTED BY
APPLICABLE LAW, r.m. FURTHER DISCLAIMS ALL WARRANTIES,
INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
NONINFRINGEMENT. THE ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE
OF THE PRODUCT AND DOCUMENTATION REMAINS WITH RECIPIENT. TO THE
MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL
r.m. BE LIABLE FOR ANY CONSEQUENTIAL, INCIDENTAL, DIRECT, INDIRECT,
SPECIAL, PUNITIVE, OR OTHER DAMAGES WHATSOEVER (INCLUDING, WITHOUT
LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION,
LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING OUT
OF THIS AGREEMENT OR THE USE OF OR INABILITY TO USE THE PRODUCT, EVEN
IF r.m. HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. BECAUSE
SOME STATES/JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF
LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE
LIMITATION MAY NOT APPLY TO RECIPIENT.

4. RESTRICTED RIGHTS AND EXPORT RESTRICTIONS.

The Product is provided with RESTRICTED RIGHTS.

Manufacturer is 

Roland Mundloch, Leinorstrasse 15a, D-85757 Karlsfeld, Bavaria, Germany 

Recipient acknowledges that the Product licensed hereunder is subject
to the export control laws and regulations of the GERMANY, and any 
amendments thereof.

5. GOVERNING LAW; ATTORNEYS FEES.

This Agreement shall be governed by the laws of the GERMANY and 
Recipient further consents to jurisdiction by the state and federal
courts sitting in MUNICH (Bavaria,GERMANY). If either r.m. or Recipient
employs attorneys to enforce any rights arising out of or relating
to this Agreement, the prevailing party shall be entitled to
recover reasonable attorneys' fees.

6. ENTIRE AGREEMENT.

This Agreement constitutes the complete and exclusive agreement
between r.m. and Recipient with respect to the subject matter hereof,
and supersedes all prior oral or written understandings,
communications or agreements not specifically incorporated herein.
This Agreement may not be modified except in a writing duly signed by
an authorized representative of r.m. and Recipient.


!!!!!!!!!!!!!!!!!!!!!!! USE ON YOUR OWN RISK !!!!!!!!!!!!!!!!!!!!!!!!!


Have fun

(c) roland mundloch 1997, all rights reserved.

Names of other hard- or software-producers/products named in the 
program are registered trademarks and should be payed attention to.
All data reserved to r.m. inclusive print/writeerror in documentation
or in the gra�hical user interface, technical improvements or other
changes.

