                          VectorJockey
----------------------------------------------------------------
An Educational Physics Game of Vector Addition of Velocity
and Acceleration in a 2-D Space.
----------------------------------------------------------------

---------------------------------------------------------------- 
PURPOSE / DESCRIPTION:
----------------------------------------------------------------

VectorJockey is designed to help teach the introductory physics 
concepts of Vector Addition, and to help students more fully 
understand differences between Velocity and Acceleration.  
Many students find it difficult to understand how an object can be
accelerating in one direction, yet moving in the opposite direction.  
Even more difficult to understand is the fact that idealized motion 
in one direction is COMPLETELY INDEPENDENT from velocity and 
acceleration in an orthogonal direction.

VectorJockey is a fun way for students to gain some interactive
experience with these concepts, and helps the students to 
internalize them.

----------------------------------------------------------------
COPYRIGHT
----------------------------------------------------------------
VectorJockey is Shareware.  Copyright� Joel Castellanos 1996-1997
---------------------------------------------------------------- 


----------------------------------------------------------------
INSTALLATION 
----------------------------------------------------------------
Run SETUP.EXE

SETUP.EXE will ask you where to install VectorJockey. SETUP.EXE 
will also install any system files required by VectorJockey that 
are not already present in your system directory. Once you have 
installed VectorJockey, you can delete all of the VectorJockey 
setup files (files with names that end with "__"), and the 
VectorJockey zipfile archive.

VectorJockey program Files:
   README.TXT     (this file)
   VECTOR.HLP   (help file)
   VECTOR.EXE   (program executable - double-click on this to run VectorJockey)


VectorJockey System files for Windows 95 or Windows NT version:
   VB40032.DLL
   VEN2232.OLB
   OLEPRO32.DLL
   MSVCRT20.DLL
   MSVCRT40.DLL
   CT13D32.DLL
   COMDLG32.DLL
   MFC40.DLL

   SETUP.EXE program will also:
   1) add a "Shortcut" to NonEuclid.exe in the system "Start" menu.
   2) add system info for uninstall.



NonEuclid System files for Windows 3.x version:
   VB40016.DLL
   OC25.DLL
   OLE2.DLL
   TYPELIB.DLL
   OLE2DISP.DLL
   OLE2PROX.DLL
   OLE2CONV.DLL
   STORAGE.DLL
   COMPOBJ.DLL
   OLE2.REG
   OLE2NLS.DLL
   STDOLE.TLB
   SCP.DLL
   VAEN21.OLB
   CTL3DV2.DLL
   COMDLG16.OCX
   
----------------------------------------------------------------
DISTRIBUTION:
----------------------------------------------------------------
You are hereby licensed to make as many copies of the Shareware 
(unregistered) version of this software, and documentation as you 
wish; give exact copies of the original Shareware version to anyone; 
and distribute the Shareware version of the software and 
documentation in its unmodified form via electronic means.  
You are specifically prohibited from charging, or requesting 
donations, for any such copies, however made; and from distributing 
the software and/or documentation with other products (commercial 
or otherwise) without prior written permission, with one exception:
Disk Vendors approved by the Association of Shareware Professionals 
are permitted to redistribute VectorJockey, subject to the 
conditions in this license, without specific written permission.


----------------------------------------------------------------
SITE LICENSE AGREEMENT:
----------------------------------------------------------------
Any school, college or university may purchases a site License for 
VectorJockey.  The holder of a site license is granted the right to 
copy the NonEuclid software, and install it on: 1) Any or all 
computers owned by the licensed institution, and 2) Any personal 
computer owned by any current faculty, staff or student of that 
institution.

----------------------------------------------------------------
SINGLE-COPY LICENSE AGREEMENT:
----------------------------------------------------------------
One registered copy of VectorJockey may either be used by a single 
person who uses the software personally on one or more computers, 
or installed on a single workstation used nonsimultaneously by 
multiple people, but not both.


----------------------------------------------------------------
EVALUATION AND REGISTRATION:
----------------------------------------------------------------
This is not free software.  You are hereby licensed to use this 
software for evaluation purposes without charge for a period of 21
days.  If you use this software after the 21 day evaluation period 
a registration fee of $10 (for a single-copy license) or $35 (for 
a site license) is required.  
Payments must be in US dollars, drawn on a US bank (personal check, 
cashier's check, or money order), and should be sent to: 
     Joel Castellanos
     8401 Spain Rd NE, Apt 18H
     Albuquerque, NM  87111.  
Be sure to include the name of the person or institution EXACTLY 
as you want it to appear on the license agreement.  Also include 
either your return postal address or e-mail address.  When payment 
is received you will be sent a license number and certificate of 
registration.  For fastest response, send payment in either a 
cashier's check or money order, and include your e-mail address.
Unregistered use of VectorJockey after the 21-day evaluation 
period is in violation of U.S. and international copyright laws.

----------------------------------------------------------------
DISCLAIMER OF WARRANTY:
----------------------------------------------------------------
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD 'AS IS' AND 
WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY 
OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED.  Because of the 
various hardware and software environments into which NonEuclid 
may be put, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS 
OFFERED.  Good data processing procedure dictates that any program 
be thoroughly tested with non-critical data before relying on it.  
The user must assume the entire risk of using the program.  
ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF PURCHASE PRICE.


----------------------------------------------------------------
AUTHOR / CONTACT INFORMATION:
----------------------------------------------------------------
VectorJockey was written by Joel Castellanos


Visit the VectorJockey Web site for more info and the latest 
version of VectorJockey:

http://riceinfo.rice.edu/projects/NonEuclid/vector

For more information, questions, ideas or suggestions - 
contact the author via e-mail:  

     joel@es.rice.edu

or via postal mail:

     8401 Spain Rd, NE, Apt# 18H,
     Albuquerque, NM, 87111



