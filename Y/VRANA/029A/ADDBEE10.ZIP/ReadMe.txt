========================================================================
       RC's Computer Lab // MATH Bee (+-) // Multi Media
========================================================================

Thank you for evaluating Math Bee (+-)!

1.  Over View
2.  System requirements
3.  Instructions
4.  Registration
5.  Disclaimer
6.  Possible Problems?/Workarounds  ( how to modify wave audio files )
/////////////////////////////////////////////////////////////////////

1.  Over View:
	This 32 bit program was designed to assist students in 
	improving their Math skills.  Addition and Subtraction 
	Skills are reinforced and assisted through the use of 
	multimedia.
	
	There are two levels in Math Bee.  The easy game selects
	numbers from 0-12 for addition and subtraction and the 
	advanced game selects numbers from 0-99.  Each and every
	game is different so the student will recieve a different
	game each time.  There is a clock that advances to keep track 
	of the elapsed time the student uses to finish a game.   A
	Time bonus will be recieved when the student finishes the game 
	with all the answers correct!

	To Further the reinfocement process a web page will be 
	dedicated for the high scores of students.  If you are a 
	registered user of "Math Bee (+ -)" you can submit your 
	childs name by filling out a form at my web site at: 
	"http://www.geocities.com/SiliconValley/Heights/7411/index.html"
	or through e-mail to: "Randel.Brock@internetMCI.com" or 
	"RCsComputerLab@usa.net".  Please include your registration 
	code, City, State, and Country in the body of the message.  
	(don't forget your childs name, age, and score)
	
2.  System Requirements:
	The Only requirements you will need is Windows 95 and a Sound 
	Card.

3.  Instructions:
	Select the level of play you desire. (Easy or Hard)
	Answer the problem in the Answer Box and hit enter.
	The answer will be checked and incorrect answers will
	be displayed.
	The game continues for 12 problems.
	You May quit at any time by pressing the Quit Button.

4.  Registration:
	This is a fully functional version of the Game during the
	trial period! The trial period expires 1 month after 
	initial installation then the game will only allow you to 
	register the software.

	The Registration Price is $14.95 (US)
	Registration allows continued use past the shareware
	expiration date.  
	Secure Web server at:
	http://wwws.wilmington.net/bmtmicro/secure_form.html
	or by regular mail.(See OrderForm.txt for details)
	
	Mail Orders To: BMT Micro	Voice Orders: 8:00am - 7:00pm EST (-5 GMT)
            	PO Box 15016		(800) 414-4268 (orders only)
            	Wilmington, NC 28408	(910) 791-7052
           	 U.S.A.

	 Fax Orders: (910) 350-2937  24 hours / 7 Days
                                  (800) 346-1672  24 hours / 7 Days

         	Online Orders via modem: (910) 350-8061  10 lines, all 14.4K
                                  (910) 799-0923  Direct 28.8K line
	Ordering and general ordering questions:
                         Via AOL: bmtmicro
                         via MSN: bmtmicro
                     Via Prodigy: HNGP66D
                  via Compuserve: 74031,307
                    via Internet: orders@bmtmicro.com
                                  telnet@bmtmicro.com
                                  http://www.bmtmicro.com


     We accept Visa, Mastercard, Discover, American Express, Diners
     Club, Carte Blanche, Cashiers Check, Personal Check.   Personal
     checks are subject to clearance.  Eurochecks in DM are welcome.
     DM, Sterling, and US Currency is welcome but send only by
     registered mail, return receipt requested.   We cannot be liable
     for lost cash sent through the mail.


5.  Disclaimer: 
	The Software (including instructions for its use) is 
	provided "AS IS" With Out Warranty of Any Kind.  
	R. C.'s Computer Lab Further Disclaims all Implied 
	Warranties Including Without Limitation Any Implied 
	Warranties of Merchantability or of  Fitness for a 
	Particular Purpose.  The Entire Risk Arising Out of the 
	Use of or the Performance of This Software and 	Documentation 
	Remains With You.
 
	In No Event Shall R.C.'s Computer Lab or Any one Else Involved 
	With the Creation, Production, Or Delivery of The Software be 
	Liable for Any Damages Whatsoever (Including, Without 
	Limitation, Damages for Loss of Business Profits, Business 
	Interruption, Loss Of Business Information, or Other Pecuniary 
	Loss) Arising Out Of the Use of This Software or Documentation,
	Even if Advised of the Possibility of Such Damages.

6.  Possible Problems:
	If program freezes when you answer the problem, you have to 
	covert the wav files.  To do this:
	1.  open sound recorder
	2.  select a wav file in the MathBee dir. 
	    (c:\ProgrramFiles\MathBee) is the default.
	3.  Select SaveAs and at the bottom of the dialog is a change 
	    button.  Hit the change button.
	4.  Select a pre-existing wav format. press ok and save.
	5.  Press play on sound recorder and you sholud be able to here 
	    the sound.
	6.  You can also record over these wav files if you want to 
	    change or modify the recordings.
		
		// Correct answers
		Correct.wav
		Correct2.wav
		Correct3.wav	
		// incorrect answers
		Incorrec.wav  

		If you modify the above files ensure you save them as
		shown above.
