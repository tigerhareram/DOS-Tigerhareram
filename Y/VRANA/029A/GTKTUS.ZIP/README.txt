Get to know the USA - Readme file

                           
WHAT IS SHAREWARE?

Shareware is a distribution method in which you "try before you buy" a
software for a period of up to 21 days.  At the end of that time, you MUST
register your copy by paying a modest fee to the author, or remove the 
program from your computer.
Registered users receive a personal registration code which removes all 
reminders from the.  By registering a Shareware program, you support
the authors' efforts to create more quality programs that will appear in the 
Shareware market.
The Shareware system makes fitting your needs easier because you can try 
before you buy.  And because the overhead is low, prices are low.  Shareware
has the ultimate money-back guarantee - if you don't use the product, you 
don't pay for it.
------------------------------------------------------------------------------

PROGRAM DESCRIPTION

Get to know the USA is an educational Windows 
program that teaches children and adults the following areas:

1.  Geography of all big cities in the US.    
2.  Geography of all US states.
3.  State information such as size, number of inhabitants, flag, capitol, etc.
4.  US  history through out the years.
5.  All US presidents, with names, party, pictures, etc.

The program not only teaches these items but also test the obtained
knowledge with a variety of tests, either on the computer
or on paper.
 
All users of the program get their own personal report which contains
the results of the latest tests. Therefore the program can be an ultimate
study tool in classrooms, also because some parts can be secured with 
password protection.
A direct connection to the support website can activatied from
within the program. On this support site you will find new tips from
other users on how to use the program, latest updates of the program
and alternative data files.
------------------------------------------------------------------------------
                           
PROGRAM REQUIREMENTS 

Get to know the USA requires the following:                            

Microsoft Windows 3.1 or higher.
A 386 or higher microprocessor.
4 MB of RAM.
The file VBRUN300.DLL which can be downloaded almost everywere,
but which will probably alreade in your WINDOWS/SYSTEM directory.

Optional: a sound device

------------------------------------------------------------------------------
                          
PROGRAM INSTALLATION

To install Get to know the USA, copy all files to
your hard disk (in any directory) and add GTKTUSA.EXE to one of your Program
Manager groups in Windows 3.x or the Windows 95 startmenu.
------------------------------------------------------------------------------
                        
CONDITIONS FOR DISTRIBUTION                           
                        
You may copy and distribute the UNREGISTERED version of the
program as long as it is the original ZIP file with the name GTKTUSA.ZIP.
If you have an doubt if the file is original, or the latest version, get the latest
version from our support site at Internet.
------------------------------------------------------------------------------                           
                           
PROGRAM DISTRIBUTION LICENSE

Individuals and organizations not requesting a fee for the distribution of
this program are encouraged to share this program with others as long as 
it is the UNREGISTERED version of the program in the original ZIP file 
with the name GTKTUSA.ZIP.
If you have an doubt if the file is original, or the latest version, get the latest
version from our support site at Internet.

If a distribution fee is charged for this software, then catalog vendors,  
users' groups, bulletin board services, online services, and other Shareware
distributors may distribute this program as long as the following conditions 
are met : 

1. You explain the shareware concept as 'try before you buy' and the price
   paid by users for shareware is a distribution charge only.
2. You sell the software for less that $9 and only sell the most current
   version of it.
3. No files are modified or deleted.
4. If you distribute this program on a CD-ROM, the packaging must contain the
   word "SHAREWARE" and/or "TRY-BEFORE-YOU-BUY".  Furthermore, you must send
   us a copy of the CD-ROM as soon as it has been manufactured.
5. Anyone wishing to sell this program in a retail environment must meet all
   of the above requirements.  In addition, you must send us a copy of your
   packaging for this program as soon as it has been manufactured.

  
If you wish to obtain our latest programs and regular updates, visit our support web site.
------------------------------------------------------------------------------
                                
DISCLAIMER

This software is sold 'as is', without any warranty as to performance or any
other warranties whether expressed or implied.  Because of the many hardware
and software environments into which this program may be used, no warranty
of fitness for a particular purpose is offered.  The user must assume the
entire risk of using this program.  
-------------------------------------------------------------------------------

SUPPORT

For any help, suggestions or other remarks, please contact our support site
at Internet at the address home.pi.net/~vdep/gtktusa.html

 If you do not have access to Internet you can write by mail or fax.

Van Dorp Educatieve Programmatuur

Postbox 268
2992 RK   Barendrecht     
The Netherlands

Fax: 0031 180 613 956
(NOTE: if you have difficulty with this number, see our web site for a new fax number) 

Internet E-mail:  vdep@pi.net    
Compuserve E-mail:  100337,3035
Our World Wide Web support site: home.pi.net/~vdep/gtktusa.html

Thank you for using our software.
