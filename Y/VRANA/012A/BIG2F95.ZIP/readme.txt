Readme Notes for Big2 and Friends for Win95
-------------------------------------------

This program will only work on operating systems capable of executing 32-bit Windows software.
It has so far been only tested on Windows 95. But the following should also work: Windows NT,
Windows 3.x with 32-bit extensions and any emulator which will run 32-bit Windows software (eg.
OS/2).

This game is currently freeware, as it is still under Beta (Alpha even) testing. Totally free for
now and to be distrubted only in its fully intact form. Right now I haven't included the rules to
the game, so if you don't know how to play: hang on a little bit longer. I will soon include a
full set of rules. Currently the AI is set to the easiest level, more "intelligent" levels will
be activated later.

Files in ZIP (big2f95.zip):
-----------------------
- BIG2F95.exe (Executable program, no extra DLLs, etc required)
- readme.txt (This file)
- update.txt (Update, bug, feature info)
- file_id.diz (Discription of program, required/preferred for BBSes)

Installation:
-------------

- Unzip big2f95.zip to a new directory

- Read the update.txt file

- Start EXE file

- Read the info on submitting bug info

- Enjoy

Contact Info:
-------------

- Read the information contained in the "Help" button

- If installation on your computer was unsuccessful please mail me at alf@loom.com.au . Please
include system info, eg. operating system, processor, RAM, etc.