Mapedit is a WYSIWYG imagemap editor for use with
World Wide Web pages. Mapedit can create both
client-side imagemaps for newer browsers and
server-side imagemaps for compatibility with
all browsers.

Mapedit requires Windows 3.1 and a 386 or better
processor. 

See the online help for detailed documentation,
covering all aspects of the program's use.

To get started, make sure mapedit.exe,
munlock.exe and mapedit.hlp are in the same
directory and launch mapedit.exe from the file
manager. You will probably want to add a program
item for mapedit to one of your groups. If you are
using Windows 95 or Windows NT, be sure to pick
up the superior 32-bit version at the URL below.

Feel free to contact us with any questions:

Boutell.Com, Inc.
P.O. Box 20837
Seattle, WA 98102
mapedit@boutell.com
http://www.boutell.com/mapedit/

