
S T A R F L I G H T

Screen Saver For Windows95(tm)

Copyright (c) 1996 Matthias Huebner
e-mail: 100745.40@compuserve.com

_________________
License Agreement
This program is FREEWARE. It is free for use and free distributable, no
registration is requiered. It is not allowed to 3. parties, to take charge for
dealing, except for transport costs. This program must shiped in original
package. It is allowed to bundel these package as a part of other packages.
All Rights Reserved.

________________
Limited Warrenty
For direct or indiret Damage, caused by using the program, the author is not
liability. The author gives no warrenty for fully, correctly or partly
functionality of the program. You are using this programm on your own risk.

The author also gives no warrenty, that the programm is free of any virus. The
user has to check it.

__________
Trademarks
Windows95 and WindowsNT are trademarks by Microsoft Cooperation.

________
Features
Yet another starflight screensaver ? not at all. StarFlight is THE "starflight
screensaver" !

* Two seperate configuratable star sets for better 3d effect
* Stars are streched depending on flight speed 
* Alternate views - f.e. controlable by mouse or animated. 
* Spectral colering of stars 
* Optional ignoring of mousemoves and clicks 
* Delayed switch to black screen 
* Pausing if any background task takes to much cpu time 
* No extra tool required - direct usable for windows

___________________
System requirements

At first you need Windows95(tm). It should run under WindowsNT(tm) too, but isn't tested yet.
This program requires a fpu unit, because it makes usage of floating point calculations. 
You need a cpu >= 80486. For the spectral colering you may need true color mode (16 bit color depth). 
Tested on Pentium(tm)-133Mhz


____________
Installation
Copy the warp.scr to your windows directory.
Using the desktop properties, you can choose and configurate the screensaver.

__________
Properties
There are a lot parameters to change the starflight behavier.

Sections:
* "View"
  Choose the kind of view and the mainspeed.

* "Ignore"
  You can protect the screensaver against mousemoves and mouseclicks.

* "Screen Save"
  After a choosable time, the screen can switched completly dark.

* "View control"
  If you choosed dynamic view, you can control the behavior here.

* "Star Parameter"
  Configure two seperatly starsets. The primary set represents the fast, near
  by flighing stars, the secondary are the far away, a bit slower flying
  stars.

* "Special"
  With "not jerky" the screensaver switch to black, if any background task
  eats to many cpu time. With "info line" the saver shows for 2 minutes the
  follwing infos: frames per second, drawn stars and total stars.

__________________
Last, but ot least
If you have any bug report or idee for the programm,
write to my e-mail:  100745.40@compuserve.com

Hamburg, 12/25/1996 - Matthias Huebner
