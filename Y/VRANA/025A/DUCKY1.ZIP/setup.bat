@echo off
ren inst.dck setup.exe
setup.exe
ren setup.exe inst.dck
notepad readme.txt
exit