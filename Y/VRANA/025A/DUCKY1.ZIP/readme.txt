Thanks for checking out DUCKY!!!, copyright 1997. 
DUCKY is an original creation 
by Jennifer Sturm.

Run SETUP.BAT to install Ducky.

DUCKY is not freeware, but you don't have to pay for DUCKY either.

Once you have decided to keep DUCKY, and you are ready to commit
to eternal subservience to the DUCK, she will accept your pledges at
her email address. Yes, DUCKY is emailware. She can be reached at

wavro@aol.com

and remember that if you register DUCKY by email, you will receive
a brand new DUCKY screen saver upon receipt of your email, so don't
miss out!!!

