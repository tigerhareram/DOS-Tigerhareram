
WELCOME TO A.V. ENTERPRISE'S PERSONAL SCREEN SAVER <www.avent.com>
******************************************************************

General
*********
"NapSnap" your Personal ScreenSaver is a Windows 3.1 & Windows 95
customizable screen saver which will enable you to personalize 
your PC's "nap time" display, using your own photos or graphics
in either GIF,BMP,PCX or JPG format, as well as sounds in WAV 
format. Your idling computer will come alive with sights and 
sounds of your own selection.
"Snap2it" is a built-in event reminder which will pop up during 
the day for which you've pre-set it, with image, sound and caption.

Installation
*************
After "unzipping" the compressed file you've downloded from the 
archive into your hard disk drive, run the "install.exe" file.
The Personal ScreenSaver is now installed as part of your Windows'
Control Panel. To set it up in Windows 95, go to the "Control Panel", 
choose "Display" and then "Settings". To set it up in Windows 3.1, 
go to the "Control Panel" choose "Desktop" and then "Settings".
Follow the yellow, on-screen instructions as you point to the 
features in the "Settings" menu,  

Registration
**************
This Shareware program you've downloaded, is a free evaluation copy 
and is fully functional, feel free to distribute it to anyone. This 
version will let you replace 3 of our demo pictures with 3 of your 
own. In order to display unlimited number of images, you'll need a 
registration code which could be obtained by accessing our web site 
at: www.avent.com  and clicking on the "Register/Order" icon. Fill 
out the order form, and a registration code will be e-mailed to you 
as soon as your credit card is approved.


Questions? Problems?
**********************
Please e-mail us at ave@orausa.com

