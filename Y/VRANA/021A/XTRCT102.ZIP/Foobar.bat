REM This is an example batch file. There may be some errors, since I haven't
REM tried it out. However, here you'll get a general idea what it could look
REM like. PleasE feel free to use it when you construct your own batchfile. 


  REM **** INITIALIZATION ****
  @ECHO OFF
  CLS
  XPROG CDDRV
  SET TMPDIR=C:\IMPORT


  REM **** TESTS IF THE RIGHT CDROM IS LOADED ****
  XPROG CDVOL
  IF NOT "%CDVOL%"=="FOOBAR" ECHO Please load the FOOBAR CDROM in Drive %CDDRV%
  IF NOT "%CDVOL%"=="FOOBAR" GOTO EXIT
  SET CDVOL=


  REM **** TESTS IF WINDOWS 95 IS LOADED ****
  XPROG WIN
  IF NOT "%WIN%"=="YES" ECHO Many batchfile entries require Win95 - please load.
  IF NOT "%WIN%"=="YES" GOTO EXIT
  SET WIN=

  REM **** THE FIRST ARGUMENT REFERS TO CORRESPONDING BATCH LABEL ****
  IF "%1%"=="DOSGAME#1" GOTO DOSGAME#1
  IF "%1%"=="DOSGAME#1" GOTO DOSGAME#2

  REM **** IF NO ARGUMENT IS GIVEN, PROVIDE HELP ****
  GOTO HELP


  REM **** LABELS: ****
  :DOSGAME#1
   C:
   XPROG ASKDIR
   XPROG MAKEDIR %DIR%
   MD %TMPDIR% >NUL
   CD %TMPDIR%
   PKUNZIP -O -D %CDDRV%:\GAME#1*.ZIP
   CD %DIR%
   ARJ X -V -R -Y %TMPDIR%\*.ARJ .
   DELTREE /Y %TMPDIR% >NUL
   INSTALL
   ECHO Install finished! Run Start to play TIC-TAC-TOE.
   PAUSE >NUL
   GOTO EXIT

  :DOSGAME#2
   C:
   MD %TMPDIR% >NUL
   CD %TMPDIR%
   PKUNZIP -O -D %CDDRV%:\GAME#2*.ZIP
   CD %DIR%
   INSTALL
   SETUP
   DELTREE /Y %TMPDIR% >NUL
   ECHO Big Heffer installed! Run PORK to play.
   PAUSE >NUL
   GOTO EXIT

  :HELP
   ECHO.
   ECHO  Syntax  : Foobar [ID]
   ECHO  Example : Foobar GAME#1
   ECHO.
   ECHO  Available Programs:        ID  
   ECHO  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
   ECHO  Tic-Tac-Toe                DOSGAME#1
   ECHO  Big Heffer                 DOSGAME#2
   ECHO.
   GOTO EXIT

  REM **** TERMINATE THE BATCH ****
  :EXIT
    SET CDDRV=
    SET TMPDIR=
    ECHO Bye Bye Cutiepie!
    ECHO.
