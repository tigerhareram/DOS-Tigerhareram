QuickRun v1.3 Update
Copyright �1996 Partridge Software
Written by Joseph Partridge
All Rights Reserved


SUMMARY

Provides a quick way of accessing commonly used applications by placing
an icon in the system tray, that when clicked, displays a menu of those
applications. Easily customizable.


REQUIREMENTS

Requires Windows 95 or NT 4.0.


INSTALLATION

1. Extract the archive using a decompression utility (PKZIP or WinZip).
2. Start QUICKRUN.EXE.


REGISTRATION

Registration is $8 (US dollars).

To register, send $8 (check or money order), along with your name, 
address, and E-Mail Address, if you have one, to:

	Joseph Partridge
	536 Fairhaven Street
	Deltona, FL 32725

When your payment is received, You will be sent your registration code.

It will be sent via E-Mail if you provided an E-Mail address, otherwise 
it will be sent via Snail-Mail (US Postal Service).

To enter your registration code, click the Register button in the 
About Box.

A Registration Dialog will be displayed. Enter your name in the first 
field and the registration code in the second field. You must enter the 
name and code EXACTLY as shown in the information sent to you. Now click 
OK to register the program.


RESTRICTIONS

I have added a feature that a registered user requested. This feature 
allows you to have the menu items either sorted or unsorted. This feature
will only be available to registered users.


DISTRIBUTION

You may freely distribute the product to anyone as long as no alterations 
are made to the files.


HISTORY

1.3	Added an option for having the menu items sorted or unsorted. 
	Fixed a bug that caused the icons to disappear when a file 
	could not be found. Also fixed a bug that caused some 
	registration codes to be invalid.

1.2     Fixed a bug in the Customize Quickrun Dialog.

1.1	The program can now run .LNK(Win95 Shortcut) files, and several 
	other interface changes.

1.01	Fixed a bug that caused the program names to be sorted 
	incorrectly.

1.0	Program Release


DISCLAIMER

THIS SOFTWARE IS ARE PROVIDED "AS IS" AND WITHOUT ANY WARRANTIES EXPRESSED
OR IMPLIED. THE USER IS RESPONIBLE FOR THE USE OF THIS PRODUCT AND ANY 
DAMAGE RESULTING FROM IT.

