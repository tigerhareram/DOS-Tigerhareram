GrokkSoft inc.                                        www.grokksoft.com


                    HoverRace BETA for Win95/NT4.0

               
                           IMPORTANT NOTES


                               content

                        - INSTALLATION
                        - STARTING HOVERRACE
                        - PLAYING ON THE INTERNET 
			            - USEFULL TIPS
                        - COMMON PROBLEMS   (SB32AWE owners look at it)


------------------------------------------------------------------------
This file contains important informations about HoverRace and 
you should read it to fully enjoy the game.

If you have any question or problem regarding this game, please do not
hesitate to contact us:

                           support@grokksoft.com
------------------------------------------------------------------------

INSTALLATION
 
  To install HoverRace you need to unzip the HoverRace package to a
  temporary folder. From there you just need to run the Setup program.

  If you already have an older HoverRace program installed on your computer,
  it it recommended that you remove it first. HoverRace can be unstalled by 
  running the "Unistall HoverRace" command located in the HoverRace folder.


STARTING HOVERRACE

  You can run HoveRace from your Windows START menu. Just click on the 
  HoverRace icon in the HoverRace folder.
 

PLAYING ON THE INTERNET 

  Just need to press F2 in the game and you will be automatically
  connected to our FREE players matching service.

  You should try the INTERNET mode to enjoy this game at the maximum.

  To type a message in the Internet Room type in the white box at the 
  bottom of the screen.

  note: Use only Microsoft TCP Stack and Dialer. Neither Trumpet stuff
        or "Internet Connect for Windows 95(CORE)" works with HoverRace.


USEFULL TIPS

   "Press SHIFT to advance"
       In HoverRace the default key to make your HoverCraft mode if 
       the SHIFT key. The UP arrow is used for jumping.

 
   "Do not get discouraged if you do not drive well at first"

       Driving an HoverCraft is not a complex task but it require 
       some dexterity. After 10 minutes of practice you will be 
       able to drive the HoverCraft like an pro. 


   "HoverCraft can be controled while they not touch ground"

       This is very usefull to avoid to fall down in a trap when 
       jumping.


   Note: For more tips please consult the HoverRace documentation 
         (F1 in the game)
       

COMMON ERRORS
 
  "ddraw.dll not found"

      You need to install DirectX on your system. Most new games will 
      soon use DirectX so it is a good idea to install it now. You can 
      found Direct X on GrokkSoft site:

         www.grokksoft.com/downloadhover.html


  "Direct sound error"  or
  "HoverRace crash"

       If you have a SB32AWE sound card you should not use the new 
       drivers provided by CreativeLab. They are incompatible with 
       DirectSound. You should use drivers provided with Windows or
       the original drivers that comes with your sound card.
   

  "I only see a grey screen when I start a game"

       Try to switch to full screen by pressing F8 or F9(try both) when 
       the game is started.


  "The game look ugly"

       Try to increase the resolution. You can resize the window or you 
       can choose a higher resolution in the "Setting" menu.


  "Refresh rate is too slow"

       Try to reduce screen resolution. You can either select the 320x200 
       display mode by pressing F8 or you can reduce displayable area with
       the minus"-" key.


  "You should be connected to the Internet to use this function"  or
  "Unable to connect to server"

       Server may be temporary out of reach. Retry later. If the situation
       persist, please contact us:

                    support@grokksoft.com


  "I'm unable to connect to an InternetGame. My delay never end computing"

        You should Use only Microsoft TCP Stack and Dialer. Neither Trumpet
        stuff or "Internet Connect for Windows 95(CORE)" works with HoverRace.


  "other error"

       Please contact us:

                    support@grokksoft.com



----------------------------------------------------------------------
 copyright 1996 GrokkSoft inc.                       www.grokksoft.com
    
