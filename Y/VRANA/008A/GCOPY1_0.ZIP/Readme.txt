c:\Doom2\levels>Xcopy *.* a:
...
Disk Full

Acc..  I  need to copy those files in to a floppy but the total
size of the files is 3Mb!
You can copy the file in more than one disks!
Ok! But how I can do this?
Take the files one by one and put them in the floppy!
Oh no! Boring, What's job of hell!
I have the solution:

      GGGGGGG  CCCCCCC  OOOOOOO  PPPPPPP  YYY      YYY
      GGGGGGG  CCCCCCC  OOOOOOO  PPPPPPP   YYY    YYY
      GGG      CCC      OOO OOO  PPP  PP    YYY  YYY
      GGG      CCC      OOO OOO  PPP  PP     YYYYYY
      GGG  GG  CCC      OOO OOO  PPPPP        YYY
      GGG  GG  CCC      OOO OOO  PPP          YYY
      GGGGGGG  CCCCCCC  OOOOOOO  PPP          YYY     By
      GGGGGGG  CCCCCCC  OOOOOOO  PPP          YYY    Gifo

This program make it easy like drink a glass of water 
and also take care to optimize the works putting in order
the files in a way to make no byte will be left of inused
space!

Thanks for the help!

--------------------------------------------------------------
Table of Contents
--------------------------------------------------------------

1.0 Gcopy Features
2.0 Important Additional Notes
3.0 Shareware, Distribution, Warrenty
4.0 Contacting the Author
5.0 Statistics

--------------------------------------------------------------
1.0 Gcopy Features
--------------------------------------------------------------

Gcopy works like copy-Xcopy dos command but: 

Gcopy  is  file  coping  utilities that fit many file from one
directory in the hard-disk into several floppy-disk.
And  also  can  split  the  big  files  into several pieces in
different disks.

Features:
  Gcopy  read  the  free space in the floppy that is placed in
  the drive and  then choose from the selected  file  the best
  combination to fill the entire disk whitout the need of make
  it manually.  
  If a file is to big for a floppy disk, Gcopy can split it in
  many  pieces  (That can have different size!) and store them
  in the floppies whit the extension .G00 .G01 etc..
  Then  can  merge  those  pieces by Gcopying the first one to
  HardDisk!
  
  To  make  effective  Scandisk  correction of eventually read
  errors  due to bad clusters on the disk is necessary to left
  a little free space. For this reason Gcopy left 10Kb of free
  space  on each disk. Olso it is possible to custom this size
  in according to the quality of the disk from a min of 1kb to
  max of 20kb.

--------------------------------------------------------------
2.0 Important Additional Notes
--------------------------------------------------------------

2.1) Gcopy  requires  a  8086  or  better  processor.  (But is
     possible that work even in worst macchine!)

2.2) To install the Gcopy I suggest to copy the file Gcopy.exe
     in the root of the Hard-Disk and include C:\ in the Path.

2.3) Wash teets after eating Cake! 


--------------------------------------------------------------
3.0 Shareware & Distribution, Warrenty
--------------------------------------------------------------

3.1 Shareware
-------------
Gcopy is a shareware program.  To register and encourage
further development, please send a Email to 
Gilmour@Freenet.hut.fi.

In the registered version:

- New Interface 
- The option Move File.
- Splitted File Preview.
- On line assistance and troubleshooting

3.2 Distribution
----------------------------
Gopy.ZIP ("the package") includes the following software
and documentation:
	Gcopy.EXE	To copy the files
	Gmove.EXE	To move the files
	Readme.txt	To read this shit
	
The package is produced 1996 by Koala Kocker Korroso.

You may copy and distribute the package through BBS and ftp
sites.  Only the unmodified Gcopy.ZIP may be distributed
or copied.
You are prohibited from:
   charging a fee or requesting donations for the package;
   distributing/including the package in commercial products;
   modifying the package.

The package may be distributed on CDROM in the case where ftp
sites issue CDROMs of their collections.  This includes the
SimTel CDROM, Garbo CDROM, Sound Site CDROM, and other
similar large collection.

All trademarks/registered names acknowledged.

3.3 Warrenty
------------
The package is provided as is, without warranty of any kind.
The author shall not be liable for damages of any kind.  Use
of this software indicates you agree to this.

--------------------------------------------------------------
4.0 Contacting the Author
--------------------------------------------------------------

For  any kind of problems or questions or if you find any bugs
contact: 
Gilmour@freenet.hut.fi

--------------------------------------------------------------
5.0 Statistics
--------------------------------------------------------------


Version 1.00 Statistics
-----------------------
	Language:	 Unknown
	Environment: 	 Dos
	Hours required:	 ???
--------------------------------------------------------------	 		

Koala Koker Korroso
Virtual Job
Gilmour@freenet.hut.fi
