
 Mellosoftron 1.0 for Windows 95
 -------------------------------
 
 The Mellosoftron turns your Windows 95 PC into a sampler   
 which can be played live with a MIDI keyboard, the computer
 keyboard or the mouse. It's also a patch editor, ideal for 
 the creation of WAVmaker and MIDInight Express patches.
 It will run with any sound card (correctly installed under 
 Windows 95) capable of playing 16 bit stereo, 22050 Hz 
 digital audio. 
 
 The Mellosoftron is shareware. Registration is only $10!
 
 SYSTEM REQUIREMENTS: 386+ (486 or better recommended). Hardware 
                      FPU recommended. MS Windows 95. 1.6 MB free 
                      disk space. High quality sound card (16 
                      bits/22050 Hz/stereo) strongly recommended.
					  
 INSTALLATION:        Run INSTALL.EXE. 
 
 If you have questions about the MIDInight Express or if you 
 experience difficulties with it, do not hesitate to contact me 
 via one of the following channels:

 SNAIL MAIL:        Tommy Anderberg
                    Almvagen 4
                    195 44 Marsta
                    SWEDEN

 E-MAIL:            Tommy.Anderberg@abc.se

 FAX:               +46 8 591 162 23
 