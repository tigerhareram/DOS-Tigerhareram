// Standard definitions needed by all files

/* TARGET_LINUX is for my (Roland's) use only. The play routine may or may
   not work under Linux at some point in the future. At the moment, it
   doesn't. Always use TARGET_MSDOS. */
#define TARGET_MSDOS   // Compiling for MS-DOS / Borland 3.1
//#define TARGET_LINUX   // Compiling for Linux 1.2.13 / GCC 2.7.0
//#define EDITOR_HOOKS
/* Things the editor needs to manage the song and player, not necessary if
   just the player is being compiled. */
//#define NDEBUG   // Turn off assert() system.
//#define DEBUG_DISPLAYS   // Some things for debugging the editor.

#define YES 1
#define NO 0
/* Note: The code interprets any nonzero value as YES. But when calling the
   subroutines which deal with bit-mapped values it is important that 1 (and
   no more) is passed. */
#define MAX_BLOCKS 100
#define MAX_PATTERNS 100
#define MAX_INSTRUMENTS 36
#define MAX_TRACKS 18
