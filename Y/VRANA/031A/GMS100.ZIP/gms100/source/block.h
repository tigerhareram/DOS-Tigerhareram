// Stuff relating to the block class

class block {
public:
  unsigned int highest_line;
  unsigned char *track_pointer[MAX_TRACKS];
  unsigned int track_bytes[MAX_TRACKS];
  
  block(unsigned int lines = 64);
  ~block();
  unsigned char *make_blank_track(unsigned int lines);
#ifdef EDITOR_HOOKS
  void swap_track(unsigned char *new_track, unsigned int old_track_number);
  void change_length(unsigned int new_length);
#endif
};
