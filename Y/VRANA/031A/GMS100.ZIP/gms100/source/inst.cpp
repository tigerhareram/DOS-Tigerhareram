#define COMPILING_INST

#include "globals.h"
#include "inst.h"

instrument::instrument() {
  type = type_synth;
  sampledata = 0;
  am_vib1.byte = 0;
  am_vib2.byte = 0;
  am_vib1.bitmap.frequency_multiple = 1;
  am_vib2.bitmap.frequency_multiple = 1;
  scaling_volume1.byte = 0;
  scaling_volume2.byte = 0;
  scaling_volume1.bitmap.volume = 16;
  scaling_volume2.bitmap.volume = 0;
  a_d1.bitmap.attack = 15;
  a_d1.bitmap.decay = 0;
  a_d2.bitmap.attack = 15;
  a_d2.bitmap.decay = 0;
  s_r1.bitmap.sustain = 7;
  s_r1.bitmap.release = 7;
  s_r2.bitmap.sustain = 7;
  s_r2.bitmap.release = 7;
  wave1.byte = 0;
  wave2.byte = 0;
  name = new char [31];
  *name = 0;
}

instrument::~instrument() {
  delete [] name;
}
