
 WAVmaker 2.4 for Windows 3.1 - Evaluation Package
 -------------------------------------------------
 
 WAVmaker 2.4 for Windows 3.1 features CD quality  MID -> WAV 
 rendering, WAV recording, tons of Digital Signal Processing 
 functions (mix, offset/maximize, fade, gate, compress, enhance, 
 low/high/band/notch filter, ring modulation, vocoder, reverse, 
 echo, reverb, flange, chorus, extend, cut, gated cut) and MIDI 
 analysis/manipulation. Full on-line documentation is included.
 
 WAVmaker is shareware. What you have received is the WAVmaker 
 Evaluation Package. For size reasons, it can't be distributed 
 with the sound library files included in the GMega Sound Library,
 which is delivered on ten standard diskettes upon registration.
 Instead, it comes with a few demo files on the old format used 
 by previous WAVmaker versions. For the corresponding files on 
 the new format, get the GMega Library Demo (gmega10.zip) e.g. 
 from WAVmaker's Home Page, http://www.abc.se/~m9303.
 
 Version 2.4 is a FREE upgrade for all registered users of version
 2.0-2.3 (Advanced AND Standard). Users with an Advanced registration 
 for versions 2.0-2.3 will still get a free update to the next major 
 release when it becomes available. Compliments of Tommy Anderberg!
 
 What's new: 
 
 - WAV recording has been added.
 - WAVmaker now "iconizes" (not quite the same as "minimizes")
   itself, or allows itself to be iconized, when rendering and
   expanding DFTs, its two most time-consuming operations. At last,
   you can set it running in the background and forget about it 
   while it does its thing!
 - In the 32 bit build, the restrictions on file names imposed for 
   backward compatibility with Windows 3.1/DOS have been removed. 
   Windows 3.1/95 users: please bear with me, but Windows 95/NT 
   purists have been insisting on this for some time now. Time to 
   make up your mind...?
 - The main window now has a "wide" (maximized) mode allowing more
   space for long filenames.
 - MID 0 to 1 conversion has been added. Amazingly, some MIDI 
   programs out there only read Level 1, not Level 0!!!!!
 - The Maximize function under WAV Edit now allows an offset (user,
   center average or center extrema) to be imposed; amplification
   can be shut off if you are only interested in the offset.
 - WAView and PRGed have been updated to reflect the improvements
   in the corresponding Mellosoftron 1.1 objects.
 - Various minor, face-lifting changes have been made to the User 
   Interface.
 - An obscure bug in mono rendering has been fixed (never reported
   by users - I stumbled on it all by myself - so I guess you won't
   notice...).
 - A Print button has been added to the Tutorial window.

 *** IMPORTANT ***: The ECHO.INI and REVERB.INI created by WAVmaker 
 2.0 are not compatible with higher versions. If you intend to 
 install WAVmaker 2.4 over version 2.0, you should delete ECHO.INI 
 and REVERB.INI first.

 The Evaluation Package may be distributed freely for evaluation 
 purposes. Full distribution and registration information is in the 
 on-line docs.
 
 SYSTEM REQUIREMENTS: 386+. FPU recommended. MS Windows 3.1.
                      3.6 MB free disk space (10+ MB recommended). 
                      High quality sound card (16 bits/44.1 kHz/
                      stereo) strongly recommended.

 NOTE: WAVmaker 2.4 is also available for Windows 95/NT.

 If at all possible, use a good amplifier/speaker system (not pitiful 
 PC gamer's speakers) to fully enjoy WAVmaker's CD quality output.
 
 INSTALLATION:        Run SETUP.EXE. 

 *** IMPORTANT ***: If you do not have a hardware floating point
 unit, and you do not have a copy of the Watcom C/C++ compiler 
 installed under Windows, you must add the following line to the 
 [386Enh] section of your SYSTEM.INI file, in the Windows directory:
 
 device=<path>WEMU387.386

 where <path> is the the directory where you have installed WAVmaker, 
 e.g. C:\WMWIN\. Windows must be restarted for this line to take 
 effect.

 If you have questions about WAVmaker or if you experience 
 difficulties with it, do not hesitate to contact me via one of the 
 following channels:

 SNAIL MAIL:        Tommy Anderberg
                    Almvagen 4
                    195 44 Marsta
                    SWEDEN

 E-MAIL:            Tommy.Anderberg@abc.se
