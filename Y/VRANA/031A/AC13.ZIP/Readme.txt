Audio Compositor 1.3

Introduction
============

Audio Compositor is software for realizing MIDI data as digital audio.
When the input comes from a standard MIDI file, Audio Compositor can
realize it as a Windows .WAV file, or if your processor is fast enough
it can play the MIDI file in real time.  When the input is a MIDI keyboard
attached to your computer, Audio Compositor behaves like a normal sound
module, though its capabilities will again be limited by the speed of your
processor.  Audio Compositor also provides a graphical environment for
editing samples and patches.

Audio Compositor runs on Windows 95, and on Windows NT 3.51 or above.  It
does not work on Win32s, though an earlier version that did is still
available from the web site at this writing.

Version 1.3 of Audio Compositor is shareware; please consider registering
it.  Registration unlocks certain features of the program that are absent
from the unregistered version.  For details, see "Register Audio Compositor..."
on the Help menu.  In its unregistered state, Audio Compositor may be freely
distributed so long as the program and all supporting files are retained and
unmodified.

While Audio Compositor is fully documented in AC.HLP, you can set up the
program quickly by following the directions below.  The distribution includes
a set of classical guitar samples and a MIDI file with which you can do a test
run.  Please note that these demonstration files were chosen for their small
size and not for their quality!

Questions, suggestions, and bug reports may be directed to mitchell@eden.com
(Scott Mitchell).  See also the Audio Compositor Home Page:

    http://www.eden.com/~mitchell


Installing Audio Compositor
===========================

There is no "setup" program for Audio Compositor; simply unzip the distribution
into a directory of your choice.  If you unzip with the directory structure
intact, there is nothing more to do; otherwise you must move the guitar samples
to a subdirectory called Samples\Guitar under the directory where the program
is installed.  For example, if you placed the files in

    d:\Dubious-looking-software\Ac

then the twelve guitar samples should be placed in

    d:\Dubious-looking-software\Ac\Samples\Guitar

If you set up an icon or shortcut to start Ac.exe, set the working directory
(the "Start in" field under Win95) to be the directory where Ac.exe is located.

To deinstall Audio Compositor, delete the files that came with the
installation, plus Ac.ini in your Windows directory.


The Leyenda Example
===================

Audio Compositor comes with one MIDI file, an abbreviated version of Isaac
Albeniz's "Leyenda" that is prepared to work with the included guitar samples.
To try it:

  1.	Run Audio Compositor (Ac.exe), choose "Open Midi File..." from
	the File menu, and open Leyenda.mid.

  2.	From the Edit menu, choose Settings.

  3.	Move to the Constants tab in the Setup dialog.  Confirm that Output
	Sample Rate is set to 22050 (this is the highest rate that the
	unregistered version supports.)  Be sure that Stereo Output is not
	checked (if you have a Pentium or faster CPU, this precaution is
	probably not needed, but the guitar samples are monophonic anyway).
	Attenuation should be set to 12 dB for this file.

  4.	Click OK to dismiss the Setup dialog.

  5.	Be sure that the the Audible button (the loudspeaker icon) is
	depressed; this turns on real-time output.

  6.	Click the Go button.

If you hear gaps in the playback, Audio Compositor is not running fast enough
to create its output in real time.  This won't affect its ability to produce
good .WAV file output.  To create an output file, repeat the steps above but
specify an Output File Name under the Files tab of the Setup dialog (you will
need about 5 megs of disk space).

Note: In the Leyenda example, you will hear some hesitation after each of the
strummed chords later in the piece.  Guitarists generally don't try to play
this passage in strict time, and the MIDI file contains tempo changes meant to
approximate the usual practice.  It's not a symptom of any timing inaccuracy
in Audio Compositor.


Warranty Disclaimer
===================

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS" AND WITHOUT ANY
WARRANTIES WHETHER EXPRESSED OR IMPLIED.  THE USER MUST ASSUME THE ENTIRE RISK
OF USING THIS PROGRAM.  ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY
TO REPLACEMENT OF THE PRODUCT OR REFUND OF PURCHASE PRICE.