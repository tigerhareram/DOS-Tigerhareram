Chord Calc v2.0.1 - Windows 3.1 Learning/reference program for guitarists

Installation: 
Run 'Setup'

Shareware: 
$25, freely distributable

Author: 
Marty Balash (mbalash@miracle.net)

Description:
Chord Calc is a reference for learning and using chords on guitar and
piano. With the emphasis on guitar, Chord Calc has 18 built-in guitar
tunings and one user-defined tuning.  Chord Calc can locate chords 
(in any tuning) from among 30 different chord types in any key, 
and on any fret on the guitar.  It can play chord voicings either 
arpeggiated or strummed, using one of 128 voices. Given a fret number, 
Chord Calc can find chord voicings for a specific area of the guitar 
neck. 

Chords of different types can be compared easily, both visually and 
by ear.  Chord Calc displays the note name or scale degree above the 
dots on the guitar chord box, making it a useful tool for studying 
chords. The chord formula and the notes in the chord are always 
displayed on the screen.

A special 12-fret view of the fretboard is available from a button 
on the main screen. This feature is especially useful when creating 
your own chord voicings or arpeggios.

Chord Calc can be custom configured, including MIDI, 
left-handed chord voicings and many other useful options.

*** end ***
